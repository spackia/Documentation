import * as express from 'express';

var _ = require('lodash');


class DevelopmentHeadersMiddleware {

    constructor(app: express.Application) {

    }

    addCustomerWebViewHeadersToRequest(req: any, res: any, next: any) {
        req.headers = _.merge(req.headers, {
            "if-none-match": "W/\"e1-1krBx+QxFS1puV7lYZomqQ\"",
            "rtazfortent": "$AP012321~P#ALL$AP106564~P#IG",
            "fac_fc": "PATTERN=.FidCust,VERSION=00.10-00.50,CREATIONTIME=1431046225,LIFETIME=1431082225,FC_RANDOM_KEY=eba6163d25922d52d14fbaf815072ade,ROLE=FidCust,STRENGTH=0005050500,FID=ffbe8a664ed49711d585840a2fd929aa77,METHOD=RtlCust,GRANTOR=Fidelity,NAVMAP=1e,RELMAP=0e,HOST=loginqa1,PROTOCOL=df.chf.ra,PRODUCT=,SESSION_KEY=554c08510a235b0720004ad00000aa330000,AUTH_OWNER=0,RULES_EXIST=16918",
            "fac_mc": "PATTERN=.FidCust,TRACKER_ID=554c08440a87481320002c050001aa33,VERSION=00.10-00.50,CREATIONTIME=1431046225,ROLE=FidCust,STRENGTH=0005050500,MID=ee00923d1674ff11d688b9ac196951aa77,RELMAP=0e,PROTOCOL=df.chf.ra,PRODUCT=",
            "fac_sc": "PATTERN=.FidCust,VERSION=00.10-00.50,CREATIONTIME=1528910785,LIFETIME=1528946785,SC_RANDOM_KEY=0fcd8b3460d1a93f42c19b7eba2e6f98,ROLE=FidCust,STRENGTH=0005050500,SID=e0fd3cc2-d54c-11e0-aeab-0a2aba15aa77,METHOD=NBPart,GRANTOR=Fidelity,RELMAP=04,HOST=loginqa1,PROTOCOL=df.chf.ra,PRODUCT=,SESSION_KEY=5b2153c00a5d37c22000e2b70000aa330000,AUTH_OWNER=0,RULES_EXIST=14303",      
            "rtazacm": "00000000000000000020",
            "rtazdefhomepage": "BENSUMM",
            "rtazlbo": "CID[000701241]-CNM[IOWA+HEALTH+PHYSICIANS]",
            "rtazuuid": "e0fd3cc2-d54c-11e0-aeab-0a2aba15aa77",
            "rtazlid": "479762983",
            "rtazallrealmslids": "InstPart=479762983",
            "fsreqid": "REQ586bc7b10ac4007d2000f6de0000aa33",
            "rtazrawacm": "00000000000000000000",
            "repid": "A609197",
            "rtazrepid": "A609197",
            "cookies":""
          });
       //   next();
    }
}

export default DevelopmentHeadersMiddleware;

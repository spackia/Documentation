
//TODO Change things that use Constants.ts to properly be referencing this new Constants Object that holds properties
let Constants = {
    CHANNEL_APP_SVS: 'APP',
    BAD_REQUEST: '401',
    PRODUCT_CODE: "DAT",
    CATEGORY_CODE: "DEF",
    ENTITY_TYPE_CODE: "PLAN",
    CHANNEL: 'DAT',
    CONTEXT: 'DAT',
    PRODUCT_VERSION: 'DX',

    TIMER: {
        DATE: 'YYYY-MM-DD',
        SECOND: 'DD/MM/YYYY hh:mm:ss',
        MILIS: 'DD/MM/YYYY hh:mm:ss:SSS',
        MOMENT: 'us',
        AVAILABLE_PATTERNS: ['YYYY-MM-DD', 'DD/MM/YYYY hh:mm:ss', 'DD/MM/YYYY hh:mm:ss:SSS']
    },
  
    APP_ORIGIN: 'APP2',
    DPCS_ORIGIN: 'DPCS',
    APP_INFO_LOG :'Origin:{0} DATApiLog:Diagnostics: client:{1}, operation:{2}, HeaderInfo:{3}, corrid:{4}, request:{5}, response:{6}, requestUri:{7}',
    PERF_LOG : 'PRODUCERSTATS|{0}|{1}|{2}|{3}|{4}|HeaderInfo:{5}|requestUri:{6}',
    APP_ERROR_LOG : 'Origin:{0}:ErrorCode:{1} DATApiError:Diagnostics: client:{2}, operation:{3}, ' +
                      'resultCode:{4}, errorString:{5}, HeaderInfo:{6}, corrid:{7}, request:{8}, response:{9}, requestUri:{10}, ',
    GENERIC_LOG_INFO : '{AppId={0}|logTrackingId={1}|febSecReqId={2}|febSecSessionId={3}|userMid={4}|repId={5}|repMid={6}|userSid={7}|repSid={8}|POE={9}|productVersion={10}}',
  
    APP_TRACKER_ORIGIN: 'TRACKER',
    //Need to make sure should we add rep information to the log.
    TRACKER_LOG_PTN : 'Origin:{0}:Tracking feature-{1}:mid-{2}:logTrackingId-{3}:febSecReqId-{4}:febSecSessionId-{5}:repId-{6}:url-{7}:productVersion-{8}',
    APP_ENSIGHTEN_ORIGIN: 'ENSIGHTEN',
    //Need to make sure should we add rep information to the log.
    ENSIGHTEN_LOG_PTN : 'Origin:{0}: Ensighten measurement tracking: measID-{1}:items-{2}:mid-{3}:logTrackingId-{4}:febSecReqId-{5}:febSecSessionId-{6}:repId-{7}:productVersion-{8}'
};
  
export default Constants;

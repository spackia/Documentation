import 'mocha';
import {expect} from 'chai';
import DevelopmentHeadersMiddleware from '../page-objects/DevelopmentHeadersMiddleware';
import * as express from 'express';

describe('DevelopmentHeadersMiddleware mock function', () => {

    var app:express.Application;
    var developmentHeadersMiddleware: DevelopmentHeadersMiddleware;

    beforeEach(() => {
        developmentHeadersMiddleware = new DevelopmentHeadersMiddleware(app);
    });

    it('DevelopmentHeadersMiddleware Class function', () => {
        /**
         * addCustomerWebViewHeadersToRequest
         */
        var req = {
            headers: {
                fsreqid: '',
                fac_mc: '1,2,3,4,5,6,7',
                repid: ''
            }
        };
        var res;
        var next;
        expect(developmentHeadersMiddleware.addCustomerWebViewHeadersToRequest(req,res, next)).to.be.a('undefined');
    });
});
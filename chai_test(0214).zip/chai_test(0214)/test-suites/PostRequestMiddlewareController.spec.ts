import 'mocha';
import {expect} from 'chai';
import { AppConfig } from '../page-objects/app.config';
import PostRequestMiddlewareController from '../page-objects/PostRequestMiddlewareController';
import * as express from 'express';

describe('PostRequestMiddlewareController mock function', () => {

    var app: express.Application;
    var postRequestMiddlewareController: PostRequestMiddlewareController;

    var controllerPath = AppConfig.APP.BASE_API_PATH;
    var _logger;

    var router = express.Router();

    beforeEach(() => {
        postRequestMiddlewareController = new PostRequestMiddlewareController(app);
     //   postRequestMiddlewareController.logger = app.get('Winston');
        postRequestMiddlewareController.intializeRoutes();
    });

    it('PostRequestMiddlewareController Class', () => {
        /**
         * errorNotFound
         */
        var req = {
            headers: {
                fsreqid: '',
                fac_mc: '1,2,3,4,5,6,7',
                repid: ''
            },
            context: {
                authenticationContext: ''
            }
        };
        var res: express.Response;
        var next;
      //  expect(postRequestMiddlewareController.errorNotFound(req,res)).to.be.a('undefined');
      /**
       * internalError
       */
      var error: any;
      var next: any;
     // expect(postRequestMiddlewareController.internalError(error, req,res, next)).to.be.a('undefined');
    });
});
import 'mocha';
import {expect} from 'chai';
import AuthContextAddingMiddleware from '../page-objects/AuthContextAddingMiddleware';
import * as express from 'express';

describe('AuthContextAddingMiddleware mock function', () => {

    var app:express.Application;
    var authContextAddingMiddleware: AuthContextAddingMiddleware;

    beforeEach(() => {
        authContextAddingMiddleware = new AuthContextAddingMiddleware(app);
    });

    it('AuthContextAddingMiddleware class function', () => {
        /**
         * addAuthContextToReq
         */
        var req = {
            headers: {
                fsreqid: '',
                fac_mc: '1,2,3,4,5,6,7',
                repid: ''
            }
        };
        var res;
        var next;
        expect(authContextAddingMiddleware.addAuthContextToReq(req,res, next)).to.be.a('undefined');
    });
});
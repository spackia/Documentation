import 'mocha';
import {expect} from 'chai';
import { AppConfig } from '../page-objects/app.config';
import RouteTrackingMiddleware from '../page-objects/RouteTrackingMiddleware';
import * as express from 'express';
import { NextFunction, Response } from "express";

describe('RouteTrackingMiddleware mock function', () => {

    var app: express.Application;
    var routeTrackingMiddleware: RouteTrackingMiddleware;

    var logger;
    var gpiOptionsHeaders;

    beforeEach(() => {
        routeTrackingMiddleware = new RouteTrackingMiddleware(app);
        gpiOptionsHeaders = {
            oauthClientId: AppConfig.OAUTH.CLIENT_ID,
            oauthClientSecret: AppConfig.OAUTH.CLIENT_SECRET,
            oauthAccessTokenUri: AppConfig.OAUTH.AUTHORIZATION_HOST,
            identityResourceBaseUri: AppConfig.BASIC_IDENTITY.APP_SVS_HOST + AppConfig.BASIC_IDENTITY.IDENTITY_PATH,
            clientOpts: { 'timeout' : AppConfig.TIMEOUT },
            app: app,
            appId: AppConfig.APP.APP_ID
        }
    });

    it('RouteTrackingMiddleware Class function', () => {
        /**
         * handleRouteTracking
         */
        var req = {
            headers: {
                fsreqid: '',
                fac_mc: '1,2,3,4,5,6,7',
                repid: ''
            },
            context: {
                authenticationContext: ''
            }
        };
        var res: express.Response;
        var next: NextFunction;
     //   expect(routeTrackingMiddleware.handleRouteTracking(req,res, next)).to.be.a('undefined');
    });
});
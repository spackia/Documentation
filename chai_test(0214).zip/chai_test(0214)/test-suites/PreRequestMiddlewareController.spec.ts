import 'mocha';
import PreRequestMiddlewareController from '../page-objects/PreRequestMiddlewareController';
import {expect} from 'chai';
import RouteTrackingMiddleware from '../page-objects/RouteTrackingMiddleware';
import AuthContextAddingMiddleware from '../page-objects/AuthContextAddingMiddleware';
import * as express from 'express';
import DevelopmentHeadersMiddleware from '../page-objects/DevelopmentHeadersMiddleware';

describe('PreRequestMiddlewareController mock function', () => {

    var preRequestMiddlewareController: PreRequestMiddlewareController;
    var app:express.Application;
    var routeTrackingMiddleware: RouteTrackingMiddleware;
    var authContextAddingMiddleware: AuthContextAddingMiddleware;
    var developmentHeaderMiddleware: DevelopmentHeadersMiddleware;
    var router = express.Router();

    beforeEach(() => {
        preRequestMiddlewareController = new PreRequestMiddlewareController(app);
        routeTrackingMiddleware = new RouteTrackingMiddleware(app);
        authContextAddingMiddleware = new AuthContextAddingMiddleware(app);
        developmentHeaderMiddleware = new DevelopmentHeadersMiddleware(app);
        preRequestMiddlewareController.intializeRoutes();
    });

    it('PreRequestMiddlewareController Class', () => {
        /**
         * intializeRoutes
         */
        expect(preRequestMiddlewareController.intializeRoutes()).to.be.a('undefined');
    });
});
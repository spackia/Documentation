import 'mocha';
import CommonUtility from '../page-objects/CommonUtility';
import {expect} from 'chai';
// const assert = require('chai').assert;
// import chai from "chai";
// let expect = chai.expect;
// let should = chai.should();

describe('CommonUtility mock function', () => {

    var commonUtility: CommonUtility;

    beforeEach(() => {
        commonUtility = new CommonUtility();
    });

    it('CommonUtility Class', () => {
        /**
         * startsWith
         */
        const result = CommonUtility.startsWith('abc', 'b');
        expect(result).to.equal(false);
        /**
         * isEmpty
         */
        expect(CommonUtility.isEmpty(null)).to.equal(true);
        /**
         * deepClone
         */
        var x = 1;
        expect(CommonUtility.deepClone(x)).to.equal(x);
        /**
         * inArray
         */
        expect(CommonUtility.inArray(5, [1,2,3])).to.equal(false);
        /**
         * getLogObjectTemplate
         */
        const expected_json = {
            origin: '',
            service : '',
            operation : '',
            request: {},
            response: {},
            timeConsumed : '',
            logUID : '',
            authContext: '',
            errorResponse: '',
            errorInfo: {
              errorCode: '',
              errorMessage: ''
            },
            febSecReqId: '',
            requestUri: ''
          };
        expect(CommonUtility.getLogObjectTemplate()).to.eql(expected_json);
        /**
         * showErrorLogMessage
         */
        const error_params = {
            errorResponse: {
                errorCode: 'Generic Result Code'
            },
            errorInfo: {
                errorMessage: '',
                errorCode: ''
            },
            authContext: {
                sessionId: '',
                repInfo: {
                    id: '',
                    mid: '',
                    sid: ''
                },
                mid: '',
                sid: '',
                trackingId: '',
                febSecReqId: '',
                pointOfEntry: '',
                productVersion: '',
                rtazlid: 0
            },
            service: '',
            operation: '',
            logUID: '',
            origin: '',
            response: '',
            requestUri: '',
            request: '',
            timeConsumed: ''
        };
        const GENERIC_LOG_INFO = '{AppId={0}|logTrackingId={1}|febSecReqId={2}|febSecSessionId={3}|userMid={4}|repId={5}|repMid={6}|userSid={7}|repSid={8}|POE={9}|productVersion={10}}';
        const APP_ID = 'AP118252';
        const APP_ORIGIN = 'APP2';
        const APP_ERROR_LOG = 'Origin:{0}:ErrorCode:{1} DATApiError:Diagnostics: client:{2}, operation:{3}, ' +
                                'resultCode:{4}, errorString:{5}, HeaderInfo:{6}, corrid:{7}, request:{8}, response:{9}, requestUri:{10}, ';

        const result_code = error_params.errorResponse && error_params.errorResponse.errorCode ? error_params.errorResponse.errorCode : 'Generic Result Code';
        error_params.errorInfo.errorMessage = CommonUtility.getLoggingString(CommonUtility.maskData(error_params.errorInfo.errorMessage), CommonUtility.maskData(error_params.errorResponse));
        const authenticationContext = error_params.authContext;
        const genericLogDetails = authenticationContext && authenticationContext.repInfo ? CommonUtility.getLoggingString(GENERIC_LOG_INFO, APP_ID, authenticationContext.trackingId,authenticationContext.febSecReqId,
        authenticationContext.sessionId,authenticationContext.mid, authenticationContext.repInfo.id, authenticationContext.repInfo.mid,
        authenticationContext.sid, authenticationContext.repInfo.sid,authenticationContext.pointOfEntry, authenticationContext.productVersion || 'DAT_1.0'): '';

        var errorLogDetails = CommonUtility.getLoggingString(APP_ERROR_LOG, error_params.origin ? error_params.origin : APP_ORIGIN,
            error_params.errorInfo.errorCode, error_params.service, error_params.operation, result_code, error_params.errorInfo.errorMessage,genericLogDetails,
            !CommonUtility.isEmpty(error_params.logUID) ? error_params.logUID : CommonUtility.getLogID(), CommonUtility.maskData(error_params.request), CommonUtility.maskData(error_params.response), error_params.requestUri);
       
        expect(CommonUtility.showErrorLogMessage(error_params)).to.be.a('string');
        /**
         * showPerfLogMsg
         */
        const APP_INFO_LOG = 'Origin:{0} DATApiLog:Diagnostics: client:{1}, operation:{2}, HeaderInfo:{3}, corrid:{4}, request:{5}, response:{6}, requestUri:{7}';
        var authenticationContext_logInfo = error_params.authContext;
        var genericLogDetails_logInfo = authenticationContext_logInfo && authenticationContext_logInfo.repInfo ? CommonUtility.getLoggingString(GENERIC_LOG_INFO, APP_ID, authenticationContext_logInfo.trackingId,authenticationContext_logInfo.febSecReqId,
            authenticationContext_logInfo.sessionId,authenticationContext_logInfo.mid, authenticationContext_logInfo.repInfo.id, authenticationContext_logInfo.repInfo.mid,
            authenticationContext_logInfo.sid, authenticationContext_logInfo.repInfo.sid,authenticationContext_logInfo.pointOfEntry, authenticationContext_logInfo.productVersion || 'DAT_1.0'): '';

        var logInfo = CommonUtility.getLoggingString(APP_INFO_LOG, error_params.origin ? error_params.origin : APP_ORIGIN, error_params.service, error_params.operation, genericLogDetails_logInfo,
            !CommonUtility.isEmpty(error_params.logUID) ? error_params.logUID : CommonUtility.getLogID(), CommonUtility.maskData(error_params.request), CommonUtility.maskData(error_params.response), error_params.requestUri);
        expect(CommonUtility.showPerfLogMsg(error_params)).to.be.a('string');
         /**
         * maskData
         * @param input
         * @returns {string}
         */
        var input:Object = '';
        CommonUtility.maskData(input);
        var maskString = typeof input == 'object' ? JSON.stringify(input) : input;
        expect(CommonUtility.maskData(input)).to.be.a('string');
        /**
         * getLogID
         * @param input
         * @returns {string}
         */
        var random_1 = Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        var random_2 = Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        var random_3 = Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        var random_4 = Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        var random_5 = Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        var random_6 = Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        var random_7 = Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        var random_8 = Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        expect(CommonUtility.getLogID()).to.be.a('string');
        /**
         * getLoggingString
         */
        expect(CommonUtility.getLoggingString()).to.be.a('string');
        /**
         * getMaskedLogMessageFromArguments
         */
        // expect(CommonUtility.getMaskedLogMessageFromArguments([1, 2, 3])).to.be.a('string');
        /**
         * getBaseLogMessageArguments
         */
        var level = '', className = '', methodName = '', authContext = error_params.authContext;
        let logTrackingId = authContext.trackingId,
            febSecReqId = authContext.febSecReqId,
            febSecSessionId = authContext.sessionId,
            userMid = authContext.mid,
            repMid = authContext.repInfo ? authContext.repInfo.mid : '',
            repId = authContext.repInfo ? authContext.repInfo.id : '',
            productVersion = authContext.productVersion || 'DX',
            rtazLid = authContext.rtazlid;
        const expected_baseMessage = [
            'level', level,
            'class', className,
            'method', methodName,
            'origin', 'app',
            'productVersion', productVersion,
            'logTrackingId', logTrackingId,
            'febSecReqId', febSecReqId,
            'febSecSessionId', febSecSessionId,
            'rtazlid', rtazLid,
            'repMid', repMid,
            'repId', repId,
            'userMid', userMid
        ];
        expect(CommonUtility.getBaseLogMessageArguments(level, className, methodName, authContext)).to.be.an('array');
        /**
         * maskLogString
         */
        // expect(CommonUtility.maskLogString('')).to.be.a('string');
        /**
         * containsValues
         * @param obj
         * @param keys
         * @returns {boolean}
         */
        var contains = true;
        var obj = []; var keys = [];
        if(!CommonUtility.isEmpty(obj) && !CommonUtility.isEmpty(keys)){
            //
        }else{
            contains = false;
        }
        expect(CommonUtility.containsValues(obj, keys)).to.be.a('boolean');
        /**
         * getTime
         */
        expect(CommonUtility.getTime()).to.be.a('number');
        /**
         * getLoggingTime
         */
        expect(CommonUtility.getLoggingTime).to.be.a('function');
        /**
         * getRouteToChannel
         */
        var str = 'toBeTruthy';
        expect(CommonUtility.getRouteToChannel(str)).to.be.a('string');
        /**
         * convertStringListToJSON
         */
        expect(CommonUtility.convertStringListToJSON('')).to.be.an('object');
    });
});
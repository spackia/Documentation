<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<style>
    .modal-backdrop.show {
        z-index: 99;
    }
</style>

<?php $__env->startSection('content'); ?>
    <!-- Top Bar Start -->
    <div class="topbar">
        <!-- Navbar -->
        <nav class="navbar-custom">

            <!-- LOGO -->
            <div class="topbar-left mt-3">
                <a href="<?php echo e(url('/')); ?>" class="logo">
                        <span>
                            <img src="<?php echo e(asset('assets/images/logo-light.png')); ?>" alt="logo-large" style="height: 30px;" class="logo-lg">
                        </span>
                </a>
            </div>

            <ul class="list-unstyled topbar-nav float-right mb-0">

                <li class="dropdown">
                    <a class="nav-link dropdown-toggle waves-effect waves-light nav-user" data-toggle="dropdown" href="#" role="button"
                       aria-haspopup="false" aria-expanded="false">
                        <img src="<?php echo e(asset('assets/images/users/user-1.jpg')); ?>" alt="profile-user" class="rounded-circle img-thumbnail mb-1"/>
                        <span class="online-icon" style="margin-left: -10px"><i class="mdi mdi-record text-success"></i></span>
                        <span class="ml-1 nav-user-name hidden-sm">
                            <?php if(Auth()->user()['permission'] > 4): ?>
                                Admin
                            <?php else: ?>
                                <?php echo e(Auth()->user()['first_name']); ?> <?php echo e(Auth()->user()['last_name']); ?>

                            <?php endif; ?>

                            <i class="mdi mdi-chevron-down"></i>
                        </span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="#"><i class="dripicons-user text-muted mr-2"></i> Profile</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" data-toggle="modal" data-animation="bounce" data-target=".bs-logout-modal-sm" href="">
                            <i class="dripicons-exit text-muted mr-2"></i> Logout</a>
                    </div>
                    <div class="modal fade bs-logout-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-sm">
                            <div class="modal-content">
                                <div class="modal-body" style="text-align: center">
                                    <h4 class="mt-2" style="text-align: center;color: white">Are you sure?</h4>
                                    <button type="button" class="btn btn-danger mt-2">
                                        <a href="<?php echo e(url('/signout')); ?>" style="color: white">Yes, Logout</a>
                                    </button>
                                    <button type="button" class="btn btn-outline-light mt-2" data-dismiss="modal">
                                        Cancel
                                    </button>
                                </div>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->
                </li>
                <li class="menu-item">
                    <!-- Mobile menu toggle-->
                    <a class="navbar-toggle nav-link" id="mobileToggle">
                        <div class="lines">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </a>
                    <!-- End mobile menu toggle-->
                </li>
            </ul>

        </nav>
        <!-- end navbar-->
    </div>
    <!-- Top Bar End -->
    <div class="page-wrapper-img" style="min-height: 111px">
        <div class="page-wrapper-img-inner d-none">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box ml-0">
                        <h4 class="page-title mb-2">
                            <i class="mdi mdi-monitor mr-2"></i>
                            <?php if(Auth()->user()['permission'] > 4): ?>
                                Leads
                            <?php else: ?>
                                Leads
                            <?php endif; ?>
                        </h4>
                        <div class="d-none">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item active">
                                    <?php if(Auth()->user()['permission'] > 4): ?>
                                        Leads
                                    <?php endif; ?>
                                </li>
                            </ol>
                        </div>
                    </div><!--end page title box-->
                </div><!--end col-->
            </div><!--end row-->
            <!-- end page title end breadcrumb -->
        </div><!--end page-wrapper-img-inner-->
    </div><!--end page-wrapper-img-->

    <div class="page-wrapper min-vh-100">
        <div class="page-wrapper-inner">

            <!-- Navbar Custom Menu -->
            <div class="navbar-custom-menu">

                <div class="container-fluid">
                    <div id="navigation">
                        <!-- Navigation Menu-->
                        <ul class="navigation-menu list-unstyled">

                            <?php if(Auth()->user()['permission'] > 4): ?>
                                <li class="has-submenu active">
                                    <a>
                                        <i class="mdi mdi-view-list"></i>
                                        Leads
                                    </a>
                                </li>
                            <?php else: ?>
                                <li class="has-submenu active">
                                    <a href="<?php echo e(url('/')); ?>">
                                        <i class="mdi mdi-view-list"></i>
                                        Leads
                                    </a>
                                </li>
                                <li class="has-submenu">
                                    <a href="<?php echo e(url('/add')); ?>">
                                        <i class="mdi mdi-account"></i>
                                        Add New Lead
                                    </a>
                                </li>
                                <li class="has-submenu">
                                    <a href="<?php echo e(url('/issue')); ?>">
                                        <i class="mdi mdi-contact-mail"></i>
                                        Issues
                                    </a>
                                </li>
                            <?php endif; ?>

                        </ul>
                        <!-- End navigation menu -->
                    </div> <!-- end navigation -->
                </div> <!-- end container-fluid -->
            </div>
            <!-- end left-sidenav-->
        </div>
        <!--end page-wrapper-inner -->
        <!-- Page Content-->
        <div class="page-content">
            <div class="container-fluid">
                <?php if(Auth()->user()['permission'] < 4): ?>
                <div class="row">
                    <div class="col-lg-2"></div>
                    <div class="col-lg-4">
                        <div class="card carousel-bg-img">
                            <div class="card-body dash-info-carousel mb-0">
                                <div class="row">
                                    <div class="col-12 align-self-center">
                                        <div class="text-center">
                                            <h4 class="mt-0 header-title text-left">Revenue</h4>
                                            <div class="icon-info my-3">
                                                <i class="dripicons-jewel bg-soft-pink"></i>
                                            </div>
                                            <h2 class="mt-0 font-weight-bold text-success">$<?php echo e($revenue); ?></h2>
                                            <p class="mb-1 text-muted">
                                                <span class="text-success">Accrued This Period</span>
                                            </p>
                                            <div class="row">
                                                <div class="col-lg-1"></div>
                                                <div class="col-lg-5 mr-0 p-0">
                                                    <button class="btn btn-success waves-effect waves-light mw-100 w-100 p-0" type="button" style="border-radius: 10px 0 0 10px">This Period</button>
                                                </div>
                                                <div class="col-lg-5 ml-0 p-0">
                                                    <button class="btn btn-secondary waves-effect waves-light mw-100 w-100 p-0" type="button" style="border-radius: 0 10px 10px 0">Total</button>
                                                </div>
                                                <div class="col-lg-1"></div>
                                            </div>
                                        </div>
                                    </div><!--end col-->
                                </div><!--end row-->
                            </div><!--end card-body-->
                        </div><!--end card-->
                    </div><!--end col-->
                    <div class="col-lg-4">
                        <div class="card carousel-bg-img">
                            <div class="card-body dash-info-carousel mb-0">
                                <div class="row">
                                    <div class="col-12 align-self-center">
                                        <div class="text-center">
                                            <h4 class="mt-0 header-title text-left">Deposite</h4>
                                            <div class="icon-info my-3">
                                                <i class="dripicons-jewel bg-soft-pink"></i>
                                            </div>
                                            <h2 class="mt-0 font-weight-bold text-purple">$<?php echo e($deposit); ?></h2>
                                            <p class="mb-1 text-muted">
                                                <span class="text-purple">
                                                    <?php if($deposit_date != ''): ?>
                                                        Will be deposited on <?php echo e($deposit_date); ?>

                                                    <?php else: ?>
                                                        Will be deposited on
                                                    <?php endif; ?>
                                                </span>
                                            </p>
                                            <div class="row invisible">
                                                <div class="col-lg-1"></div>
                                                <div class="col-lg-5 mr-0 p-0">
                                                    <button class="btn btn-success waves-effect waves-light mw-100 w-100 p-0" type="button" style="border-radius: 10px 0 0 10px">This Period</button>
                                                </div>
                                                <div class="col-lg-5 ml-0 p-0">
                                                    <button class="btn btn-secondary waves-effect waves-light mw-100 w-100 p-0" type="button" style="border-radius: 0 10px 10px 0">Total</button>
                                                </div>
                                                <div class="col-lg-1"></div>
                                            </div>
                                        </div>
                                    </div><!--end col-->
                                </div><!--end row-->
                            </div><!--end card-body-->
                        </div><!--end card-->
                    </div><!--end col-->
                    <div class="col-lg-2"></div>
                </div><!--end Reposit-->
                <?php endif; ?>
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <div class="card">
                           <div class="card-body table-responsive">
                              <div class="">
                                  <table id="lead_datatable" class="table dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                       <thead>
                                           <tr>
                                               <th>Client</th>
                                               <th>Date submitted</th>
                                               <th>Days in System</th>
                                               <th>Lead Stage</th>
                                               <th>Payout Amount</th>
                                               <th>Payout Date</th>
                                           </tr>
                                       </thead>
                                       <tbody>
                                       <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                           <tr>
                                               <td><?php echo e($lead->first_name); ?> <?php echo e($lead->last_name); ?></td>
                                               <td><?php echo e($lead->created_at->format('M-d-Y')); ?></td>
                                               <td><?php echo e($lead->created_at->diffForHumans(null, $today).' '); ?></td>
                                               <td>
                                                   <?php if(Auth()->user()['permission'] > 4): ?>
                                                   <select class="form-control" onchange="updateStatus(<?php echo e($lead->id); ?>, this)" >
                                                       <option value="0" <?php if($lead->status == 0): ?> selected <?php endif; ?>>Lead received</option>
                                                       <option value="1" <?php if($lead->status == 1): ?> selected <?php endif; ?>>Reached out to client</option>
                                                       <option value="2" <?php if($lead->status == 2): ?> selected <?php endif; ?>>Client submitted application</option>
                                                       <option value="3" <?php if($lead->status == 3): ?> selected <?php endif; ?>>Underwriting</option>
                                                       <option value="4" <?php if($lead->status == 4): ?> selected <?php endif; ?>>Loan approved</option>
                                                       <option value="5" <?php if($lead->status == 5): ?> selected <?php endif; ?>>Loan rejected</option>
                                                       <option value="6" <?php if($lead->status == 6): ?> selected <?php endif; ?>>Funded</option>
                                                       <option value="7" <?php if($lead->status == 7): ?> selected <?php endif; ?>>Payout sent to affiliate</option>
                                                   </select>
                                                   <?php endif; ?>
                                                   <?php if(Auth()->user()['permission'] < 4): ?>
                                                       <?php if($lead->status == 0): ?>Lead received
                                                       <?php elseif($lead->status == 1): ?>Reached out to client
                                                       <?php elseif($lead->status == 2): ?>Client submitted application
                                                       <?php elseif($lead->status == 3): ?>Underwriting
                                                       <?php elseif($lead->status == 4): ?>Loan approved
                                                       <?php elseif($lead->status == 5): ?>Loan rejected
                                                       <?php elseif($lead->status == 6): ?>Funded
                                                       <?php elseif($lead->status == 7): ?>Payout sent to affiliate
                                                       <?php endif; ?>
                                                   <?php endif; ?>
                                               </td>
                                               <td>
                                                   <span id="amount_<?php echo e($lead->id); ?>">
                                                   <?php if($lead->status == 4 or $lead->status == 6 or $lead->status == 7): ?>
                                                       $500
                                                   <?php else: ?>
                                                       N/A
                                                   <?php endif; ?>
                                                   </span>
                                               </td>
                                               <td>
                                                   <span id="payout_date_<?php echo e($lead->id); ?>">
                                                   <?php if($lead->status == 7 && $lead->payout_date != ''): ?>
                                                       <?php echo e($lead->payout_date); ?>

                                                   <?php else: ?>
                                                       N/A
                                                   <?php endif; ?>
                                                   </span>
                                               </td>
                                           </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                       </tbody>
                                   </table>
                              </div>
                           </div>
                        </div>
                    </div>
                </div><!--end row-->

            </div><!-- container -->

            <footer class="footer text-center text-sm-left">
                &copy; 2020 24hr Fast Funding Capital
            </footer>
        </div>
        <!-- end page content -->
    </div>
    <!-- end page-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/plugins/tiny-editable/mindmup-editabletable.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/tiny-editable/numeric-input-example.js')); ?>"></script>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Buttons examples -->
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/pages/jquery.datatable.init.js')); ?>"></script>
    <script>
        function  updateStatus(id, selectObject) {
            $.ajax({
                url:'/index.php/leads/edit/stage',
                type:'post',
                data: {
                    'value': selectObject.value,
                    'id': id,
                    '_token': '<?php echo csrf_token(); ?>'
                },
                success: function(res) {
                    var d = new Date();
                    var date = d.getDate();
                    if (date < 10) date = '0' + date;
                    var month = d.getMonth() + 1;
                    if (month < 10) month = '0' + month;
                    var year = d.getFullYear();
                    var dateStr = year + "-" + month + "-" + date;

                    if (selectObject.value == 4 || selectObject.value == 6 || selectObject.value == 7)
                        $('#amount_'+id).text('$500');
                    else
                        $('#amount_'+id).text('N/A');
                    if (selectObject.value == 7)
                        $('#payout_date_'+id).text(dateStr);
                    else $('#payout_date_'+id).text('N/A');
                },
                error: function (res) {
                    console.log('failure')
                }
            });
        }

        $(document).ready(function() {

            $(document).ready(function() {
                $('#lead_datatable').DataTable();
            } );
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
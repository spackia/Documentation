<?php
use App\Cat;

//$languages = ['en', 'zh'];
$relPath = env('RELATIVE_URL', '');
Config::set('RELATIVE_URL', $relPath);
$frontPath = env('FRONT_URL', '');
Config::set('FRONT_URL', $frontPath);

$title = "24hr Fast Funding Capital";

Config::set('SITE_TITLE', $title);


Route::get ( '/getWords', 'WordController@getWords' );

Auth::routes();
Route::get('/signin', 'Auth\AuthController@signin')->name('signin');
Route::get('/signout', 'Auth\AuthController@signout')->name('signout');
Route::get('/register', 'Auth\AuthController@register')->name('register');

Route::get('user/activation/{token}', 'Auth\LoginController@activateUser')->name('user.activate');


Route::get ( '/', ['as' => 'admin.uses', 'uses' => 'UserController@index']);
Route::get('/add', 'LeadController@index')->name('add');
Route::get('/issue', 'LeadController@goIssue')->name('issue');
Route::get('/users', 'UserController@goUsers')->name('users');
Route::post('/user/delete', 'UserController@deleteUser');

Route::post('/issue', 'LeadController@postIssue');
Route::post('/add', 'LeadController@addLead');
Route::post('/leads/edit/stage', 'LeadController@updateStage');



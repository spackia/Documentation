'use strict';

window.routes = [
	{
		path: '/',
		componentUrl: './partials/screens/splash.html'
	},
	{
		path: '/walkthrough',
		componentUrl: './partials/screens/walkthrough.html'
	},
	{
		path: '/home',
		componentUrl: './partials/screens/home.html'
	},
	{
		path: '/components',
		componentUrl: './partials/components.html',
		routes: [
			{
				path: '/accordion',
				componentUrl: './partials/components/accordion.html'
			},
			{
				path: '/action-sheet',
				componentUrl: './partials/components/action-sheet.html'
			},
			{
				path: '/autocomplete',
				componentUrl: './partials/components/autocomplete.html'
			},
			{
				path: '/badge',
				componentUrl: './partials/components/badge.html'
			},
			{
				path: '/button',
				componentUrl: './partials/components/button.html'
			},
			{
				path: '/cards',
				componentUrl: './partials/components/cards.html'
			},
			{
				path: '/checkbox',
				componentUrl: './partials/components/checkbox.html'
			},
			{
				path: '/chips',
				componentUrl: './partials/components/chips.html'
			},
			{
				path: '/content-block',
				componentUrl: './partials/components/content-block.html'
			},
			{
				path: '/data-table',
				componentUrl: './partials/components/data-table.html'
			},
			{
				path: '/datepicker',
				componentUrl: './partials/components/datepicker.html'
			},
			{
				path: '/dialog',
				componentUrl: './partials/components/dialog.html'
			},
			{
				path: '/floating-action-button',
				componentUrl: './partials/components/floating-action-button.html',
				routes: [
					{
						path: '/default',
						componentUrl: './partials/components/fab-default.html'
					},
					{
						path: '/extended',
						componentUrl: './partials/components/fab-extended.html'
					},
					{
						path: '/speed-dial',
						componentUrl: './partials/components/fab-speed-dial.html'
					},
					{
						path: '/morph-searchbar',
						componentUrl: './partials/components/fab-morph-searchbar.html'
					},
					{
						path: '/morph-toolbar',
						componentUrl: './partials/components/fab-morph-toolbar.html'
					}
				]
			},
      {
				path: '/form-elements',
				componentUrl: './partials/components/form-elements.html'
			},
      {
				path: '/form-validator',
				componentUrl: './partials/components/form-validator.html'
			},
			{
				path: '/gauge',
				componentUrl: './partials/components/gauge.html'
			},
			{
				path: '/grid',
				componentUrl: './partials/components/grid.html'
			},
			{
				path: '/hamburger',
				componentUrl: './partials/components/hamburger.html'
			},
			{
				path: '/infinite-scroll',
				componentUrl: './partials/components/infinite-scroll.html'
			},
			{
				path: '/keypad',
				componentUrl: './partials/components/keypad.html'
			},
			{
				path: '/lazy-load',
				componentUrl: './partials/components/lazy-load.html'
			},
			{
				path: '/list-index',
				componentUrl: './partials/components/list-index.html'
			},
			{
				path: '/list-view',
				componentUrl: './partials/components/list-view.html'
			},
			{
				path: '/navbar',
				componentUrl: './partials/components/navbar.html',
				routes: [
					{
						path: '/fixed',
						componentUrl: './partials/components/navbar-fixed.html'
					},
					{
						path: '/hide-on-scroll',
						componentUrl: './partials/components/navbar-hide-on-scroll.html'
					}
				]
			},
			{
				path: '/note',
				componentUrl: './partials/components/note.html'
			},
			{
				path: '/notification',
				componentUrl: './partials/components/notification.html'
			},
			{
				path: '/photo-browser',
				componentUrl: './partials/components/photo-browser.html'
			},
			{
				path: '/picker',
				componentUrl: './partials/components/picker.html'
			},
			{
				path: '/popover',
				componentUrl: './partials/components/popover.html'
			},
			{
				path: '/popup',
				componentUrl: './partials/components/popup.html'
			},
			{
				path: '/preloader',
				componentUrl: './partials/components/preloader.html'
			},
			{
				path: '/progress-bar',
				componentUrl: './partials/components/progress-bar.html'
			},
			{
				path: '/pull-to-refresh',
				componentUrl: './partials/components/pull-to-refresh.html'
			},
			{
				path: '/radio',
				componentUrl: './partials/components/radio.html'
			},
			{
				path: '/range-slider',
				componentUrl: './partials/components/range-slider.html'
			},
			{
				path: '/rating',
				componentUrl: './partials/components/rating.html'
			},
			{
				path: '/searchbar',
				componentUrl: './partials/components/searchbar.html',
				routes: [
					{
						path: '/fixed',
						componentUrl: './partials/components/searchbar-fixed.html'
					},
					{
						path: '/static',
						componentUrl: './partials/components/searchbar-static.html'
					},
					{
						path: '/expandable',
						componentUrl: './partials/components/searchbar-expandable.html'
					}
				]
			},
			{
				path: '/sheet-modal',
				componentUrl: './partials/components/sheet-modal.html'
			},
			{
				path: '/side-panel',
				componentUrl: './partials/components/side-panel.html'
			},
			{
				path: '/smart-select',
				componentUrl: './partials/components/smart-select.html'
			},
			{
				path: '/sortable-list',
				componentUrl: './partials/components/sortable-list.html'
			},
			{
				path: '/stepper',
				componentUrl: './partials/components/stepper.html'
			},
			{
				path: '/subnavbar',
				componentUrl: './partials/components/subnavbar.html'
			},
			{
				path: '/swipeout',
				componentUrl: './partials/components/swipeout.html'
			},
			{
				path: '/swiper-slider',
				componentUrl: './partials/components/swiper-slider.html',
				routes: [
					{
						path: '/horizontal',
						componentUrl: './partials/components/swiper-slider-horizontal.html'
					},
					{
						path: '/vertical',
						componentUrl: './partials/components/swiper-slider-vertical.html'
					}
				]
			},
			{
				path: '/tabs',
				componentUrl: './partials/components/tabs.html',
				routes: [
					{
						path: '/static',
						componentUrl: './partials/components/tabs-static.html'
					},
					{
						path: '/animated',
						componentUrl: './partials/components/tabs-animated.html'
					},
					{
						path: '/swipeable',
						componentUrl: './partials/components/tabs-swipeable.html'
					},
					{
						path: '/tabbar',
						componentUrl: './partials/components/tabbar.html'
					}
				]
			},
			{
				path: '/timeline',
				componentUrl: './partials/components/timeline.html',
				routes: [
					{
						path: '/vertical',
						componentUrl: './partials/components/timeline-vertical.html'
					},
					{
						path: '/horizontal',
						componentUrl: './partials/components/timeline-horizontal.html'
					},
					{
						path: '/calendar',
						componentUrl: './partials/components/timeline-calendar.html'
					}
				]
			},
			{
				path: '/timepicker',
				componentUrl: './partials/components/timepicker.html'
			},
			{
				path: '/toast',
				componentUrl: './partials/components/toast.html'
			},
			{
				path: '/toggle',
				componentUrl: './partials/components/toggle.html'
			},
			{
				path: '/toolbar',
				componentUrl: './partials/components/toolbar.html',
				routes: [
					{
						path: '/static',
						componentUrl: './partials/components/toolbar-static.html'
					},
					{
						path: '/fixed',
						componentUrl: './partials/components/toolbar-fixed.html'
					},
					{
						path: '/hide-on-scroll',
						componentUrl: './partials/components/toolbar-hide-on-scroll.html'
					}
				]
			},
			{
				path: '/tooltip',
				componentUrl: './partials/components/tooltip.html'
			},
			{
				path: '/virtual-list',
				componentUrl: './partials/components/virtual-list.html'
			},
		]
	},
	{
		path: '/screens',
		componentUrl: './partials/screens.html',
		routes: [
			{
				path: '/fungicidas',
				componentUrl: './partials/screens/fungicidas.html'
			},
			{
				path: '/herbicidas',
				componentUrl: './partials/screens/herbicidas.html'
			},
			{
				path: '/insecticidas',
				componentUrl: './partials/screens/insecticidas.html'
			},
			{
				path: '/provitta',
				componentUrl: './partials/screens/provitta.html'
			},
			{
				path: '/404',
				componentUrl: './partials/screens/404.html'
			},
			{
				path: '/about',
				componentUrl: './partials/screens/about.html'
			},
			{
				path: '/activity-feed',
				componentUrl: './partials/screens/activity-feed.html'
			},
			{
				path: '/articles-list',
				componentUrl: './partials/screens/articles-list.html'
			},
			{
				path: '/articles-single',
				componentUrl: './partials/screens/articles-single.html'
			},
			{
				path: '/business-profile',
				componentUrl: './partials/screens/business-profile.html'
			},
			{
				path: '/careers',
				componentUrl: './partials/screens/careers.html'
			},
			{
				path: '/cart',
				componentUrl: './partials/screens/cart.html'
			},
			{
				path: '/chat',
				componentUrl: './partials/screens/chat.html'
			},
			{
				path: '/checkout',
				componentUrl: './partials/screens/checkout.html'
			},
			{
				path: '/coming-soon',
				componentUrl: './partials/screens/coming-soon.html'
			},
			{
				path: '/contact-us',
				componentUrl: './partials/screens/contact-us.html',
				beforeEnter: function(routeTo, routeFrom, resolve, reject) {
					app.preloader.show();
					if (window.google && window.google.maps) {
						app.preloader.hide();
						resolve();
					}
					else {
						var language = app.utils.i18n.getLanguage();
						LazyLoad.js(['https://maps.googleapis.com/maps/api/js?key=' + app.data.config.googleMaps.apiKey + '&language=' + language.lang + '&libraries=places'], function() {
							app.preloader.hide();
							resolve();
						});
					}
				}
			},
			{
				path: '/contacts-list',
				componentUrl: './partials/screens/contacts-list.html'
			},
			{
				path: '/cookies',
				componentUrl: './partials/screens/cookies.html'
			},
			{
				path: '/event',
				componentUrl: './partials/screens/event.html'
			},
			{
				path: '/events-calendar',
				componentUrl: './partials/screens/events-calendar.html'
			},
			{
				path: '/faq',
				componentUrl: './partials/screens/faq.html'
			},
			{
				path: '/feedback',
				componentUrl: './partials/screens/feedback.html'
			},
			{
				path: '/forgot-password',
				componentUrl: './partials/screens/forgot-password.html'
			},
			{
				path: '/home',
				componentUrl: './partials/screens/home.html'
			},
			{
				path: '/invite-friends',
				componentUrl: './partials/screens/invite-friends.html'
			},
			{
				path: '/login',
				componentUrl: './partials/screens/login.html'
			},
			{
				path: '/notifications',
				componentUrl: './partials/screens/notifications.html'
			},
			{
				path: '/otp-verification',
				componentUrl: './partials/screens/otp-verification.html'
			},
			{
				path: '/privacy',
				componentUrl: './partials/screens/privacy.html'
			},
			{
				path: '/products-list',
				componentUrl: './partials/screens/products-list.html'
			},
			{
				path: '/products-single',
				componentUrl: './partials/screens/products-single.html'
			},
			{
				path: '/profile-setup',
				componentUrl: './partials/screens/profile-setup.html'
			},
			{
				path: '/recipe',
				componentUrl: './partials/screens/recipe.html'
			},
			{
				path: '/settings',
				componentUrl: './partials/screens/settings.html'
			},
			{
				path: '/signup',
				componentUrl: './partials/screens/signup.html'
			},
			{
				path: '/signup/email',
				componentUrl: './partials/screens/signup-email.html'
			},
			{
				path: '/splash',
				componentUrl: './partials/screens/splash.html'
			},
			{
				path: '/team',
				componentUrl: './partials/screens/team.html'
			},
			{
				path: '/terms',
				componentUrl: './partials/screens/terms.html'
			},
			{
				path: '/testimonials',
				componentUrl: './partials/screens/testimonials.html'
			},
			{
				path: '/under-maintenance',
				componentUrl: './partials/screens/under-maintenance.html'
			},
			{
				path: '/user-profile',
				componentUrl: './partials/screens/user-profile.html'
			},
			{
				path: '/walkthrough',
				componentUrl: './partials/screens/walkthrough.html'
			}
		]
	},
	{
		path: '/la-empresa',
		componentUrl: './partials/screens/la-empresa.html'
	},
	{
		path: '/sigev',
		componentUrl: './partials/screens/sigev.html'
	},
	{
		path: '/aceites',
		componentUrl: './aceites/aceites.html',
		routes: [
			{
				path: 'leaf_oil',
				componentUrl: './aceites/leaf_oil.html'
			},
			{
				path: 'sticker_oil',
				componentUrl: './aceites/sticker_oil.html'
			},
		]
	},
	{
		path: '/curasemillas',
		componentUrl: './curasemillas/curasemillas.html',
		routes: [
			{
				path: '/bellator',
				componentUrl: './curasemillas/bellator.html'
			},
			{
				path: '/bellator_quattour',
				componentUrl: './curasemillas/bellator_quattour.html'
			},
			{
				path: 'halo',
				componentUrl: './curasemillas/halo.html'
			},
			{
				path: 'huracan-25fs',
				componentUrl: './curasemillas/huracan-25fs.html'
			},
			{
				path: 'kcique-60fs',
				componentUrl: './curasemillas/kcique-60fs.html'
			},
			{
				path: 'kuraprid',
				componentUrl: './curasemillas/kuraprid.html'
			},
			{
				path: 'leaf_oil',
				componentUrl: './curasemillas/leaf_oil.html'
			},
			{
				path: 'only_35fs',
				componentUrl: './curasemillas/only_35fs.html'
			},
			{
				path: 'only-60ts',
				componentUrl: './curasemillas/only-60ts.html'
			},
			{
				path: 'sticker_oil',
				componentUrl: './curasemillas/sticker_oil.html'
			},
		]
	},
	{
		path: '/fungicidas',
		componentUrl: './fungicidas/fungicidas.html',
		routes: [
			{
				path: '/baret-duo',
				componentUrl: './fungicidas/baret-duo.html'
			},
			{
				path: '/bendazim',
				componentUrl: './fungicidas/bendazim.html'
			},
			{
				path: '/contact',
				componentUrl: './fungicidas/contact.html'
			},
			{
				path: '/equation',
				componentUrl: './fungicidas/equation.html'
			},
			{
				path: '/genesis-duo',
				componentUrl: './fungicidas/genesis-duo.html'
			},
			{
				path: '/genesis-gold',
				componentUrl: './fungicidas/genesis-gold.html'
			},
			{
				path: 'genesis-gram',
				componentUrl: './fungicidas/genesis-gram.html'
			},
			{
				path: 'genesis-max',
				componentUrl: './fungicidas/genesis-max.html'
			},
			{
				path: 'hurler',
				componentUrl: './fungicidas/hurler.html'
			},
			{
				path: 'muralla',
				componentUrl: './fungicidas/muralla.html'
			},
			{
				path: 'muralla-75wg',
				componentUrl: './fungicidas/muralla-75wg.html'
			},
			{
				path: 'prosoy-t',
				componentUrl: './fungicidas/prosoy-t.html'
			},
			{
				path: 'prosoy-total',
				componentUrl: './fungicidas/prosoy-total.html'
			},
			{
				path: 'prosoyduo',
				componentUrl: './fungicidas/prosoyduo.html'
			},
			{
				path: 'prosoytrio',
				componentUrl: './fungicidas/prosoytrio.html'
			},
			{
				path: 'tricur',
				componentUrl: './fungicidas/tricur.html'
			},
		]
	},
		{
		path: '/herbicidas',
		componentUrl: './herbicidas/herbicidas.html',
		routes: [
			{
				path: '/2-4d-amina',
				componentUrl: './herbicidas/2-4d-amina.html'
			},
			{
				path: '/2-4d-tm-zero',
				componentUrl: './herbicidas/2-4d-tm-zero.html'
			},
			{
				path: '/arrange',
				componentUrl: './herbicidas/arrange.html'
			},
			{
				path: 'atramyl-50sc',
				componentUrl: './herbicidas/atramyl-50sc.html'
			},
			{
				path: 'atramyl-50sc-plus',
				componentUrl: './herbicidas/atramyl-50sc-plus.html'
			},
			{
				path: 'bushkill',
				componentUrl: './herbicidas/bushkill.html'
			},
			{
				path: 'confirm-84wg',
				componentUrl: './herbicidas/confirm-84wg.html'
			},
			{
				path: 'docendo',
				componentUrl: './herbicidas/docendo.html'
			},
			{
				path: 'fusil',
				componentUrl: './herbicidas/fusil.html'
			},
			{
				path: 'grammyl',
				componentUrl: './herbicidas/grammyl.html'
			},
			{
				path: 'magnum',
				componentUrl: './herbicidas/magnum.html'
			},
			{
				path: 'sendero',
				componentUrl: './herbicidas/sendero.html'
			},
			{
				path: 'tecnup',
				componentUrl: './herbicidas/tecnup.html'
			},
			{
				path: 'tecnup-premium',
				componentUrl: './herbicidas/tecnup-premium.html'
			},
			{
				path: 'tecnup-premium2',
				componentUrl: './herbicidas/tecnup-premium2.html'
			},
			{
				path: 'tecnup-wg',
				componentUrl: './herbicidas/tecnup-wg.html'
			},
			{
				path: 'tecnup-xtra',
				componentUrl: './herbicidas/tecnup-xtra.html'
			},
			{
				path: 'tecnoquat-sl',
				componentUrl: './herbicidas/tecnoquat-sl.html'
			},
			{
				path: 'temible',
				componentUrl: './herbicidas/temible.html'
			},
			{
				path: 'todym-24ec',
				componentUrl: './herbicidas/todym-24ec.html'
			},
			{
				path: 'vincitone',
				componentUrl: './herbicidas/vincitone.html'
			},
			{
				path: 'zethapyr',
				componentUrl: './herbicidas/zethapyr.html'
			},
		]
	},
	{
		path: '/insecticidas',
		componentUrl: './insecticidas/insecticidas.html',
		routes: [
			{
				path: '/abamec',
				componentUrl: './insecticidas/abamec.html'
			},
			{
				path: '/acefato-95sg',
				componentUrl: './insecticidas/acefato-95sg.html'
			},
			{
				path: 'apport',
				componentUrl: './insecticidas/apport.html'
			},
			{
				path: 'clorfos',
				componentUrl: './insecticidas/clorfos.html'
			},
			{
				path: 'concept-80wg',
				componentUrl: './insecticidas/concept-80wg.html'
			},
			{
				path: 'dagger',
				componentUrl: './insecticidas/dagger.html'
			},
			{
				path: 'fenthrin',
				componentUrl: './insecticidas/fenthrin.html'
			},
			{
				path: 'fentdiez',
				componentUrl: './insecticidas/fentdiez.html'
			},
			{
				path: 'hornero-20sp',
				componentUrl: './insecticidas/hornero-20sp.html'
			},
			{
				path: 'hornero-70wp',
				componentUrl: './insecticidas/hornero-70wp.html'
			},
			{
				path: 'huracan-80wg',
				componentUrl: './insecticidas/huracan-80wg.html'
			},
			{
				path: 'judo-k',
				componentUrl: './insecticidas/judo-k.html'
			},
			{
				path: 'k-cique-60foliar',
				componentUrl: './insecticidas/k-cique-60foliar.html'
			},
			{
				path: 'k-fol',
				componentUrl: './insecticidas/k-fol.html'
			},
			{
				path: 'mentor-48wg',
				componentUrl: './insecticidas/mentor-48wg.html'
			},
			{
				path: 'metomyl-tm',
				componentUrl: './insecticidas/metomyl-tm.html'
			},
			{
				path: 'noctur-10sl',
				componentUrl: './insecticidas/noctur-10sl.html'
			},
			{
				path: 'noctur-plus',
				componentUrl: './insecticidas/noctur-plus.html'
			},
			{
				path: 'noctur-plus-25sc',
				componentUrl: './insecticidas/noctur-plus-25sc.html'
			},
			{
				path: 'only-plus',
				componentUrl: './insecticidas/only-plus.html'
			},
			{
				path: 'only-60sc',
				componentUrl: './insecticidas/only-60sc.html'
			},
			{
				path: 'overtop',
				componentUrl: './insecticidas/overtop.html'
			},
			{
				path: 'point',
				componentUrl: './insecticidas/point.html'
			},
			{
				path: 'soyguard',
				componentUrl: './insecticidas/soyguard.html'
			},
			{
				path: 'strong',
				componentUrl: './insecticidas/strong.html'
			},
			{
				path: 'spinner',
				componentUrl: './insecticidas/spinner.html'
			},
			{
				path: 'supermyl',
				componentUrl: './insecticidas/supermyl.html'
			},
			{
				path: 'triplo-x',
				componentUrl: './insecticidas/triplo-x.html'
			},
			{
				path: 'yeldon',
				componentUrl: './insecticidas/yeldon.html'
			},
		]
	},
	{
		path: '/provitta',
		componentUrl: './provitta/provitta.html',
		routes: [
			{
				path: '/boro-10-tm',
				componentUrl: './provitta/boro-10-tm.html'
			},
			{
				path: '/grano-k-tm',
				componentUrl: './provitta/grano-k-tm.html'
			},
			{
				path: '/litus-tm',
				componentUrl: './provitta/litus-tm.html'
			},
			{
				path: '/one-drop-tm',
				componentUrl: './provitta/one-drop-tm.html'
			},
			{
				path: 'protein-tm',
				componentUrl: './provitta/protein-tm.html'
			},
			{
				path: 'regulator-tm',
				componentUrl: './provitta/regulator-tm.html'
			},
			{
				path: 'seedguard-tm',
				componentUrl: './provitta/seedguard-tm.html'
			},
			{
				path: 'spill-drop-tm',
				componentUrl: './provitta/spill-drop-tm.html'
			},
			{
				path: 'viggora-tm',
				componentUrl: './provitta/viggora-tm.html'
			},
		]
	},
	{
		path: '/cordova-plugins',
		componentUrl: './partials/cordova-plugins.html',
		routes: [
			{
				path: '/battery-status',
				componentUrl: './partials/cordova-plugins/battery-status.html'
			},
			{
				path: '/build-info',
				componentUrl: './partials/cordova-plugins/build-info.html'
			},
			{
				path: '/device',
				componentUrl: './partials/cordova-plugins/device.html'
			},
			{
				path: '/dialogs',
				componentUrl: './partials/cordova-plugins/dialogs.html'
			},
			{
				path: '/fingerprint-authentication',
				componentUrl: './partials/cordova-plugins/fingerprint-authentication.html'
			},
			{
				path: '/geolocation',
				componentUrl: './partials/cordova-plugins/geolocation.html'
			},
			{
				path: '/inappbrowser',
				componentUrl: './partials/cordova-plugins/inappbrowser.html'
			},
			{
				path: '/local-notification',
				componentUrl: './partials/cordova-plugins/local-notification.html'
			},
			{
				path: '/network-information',
				componentUrl: './partials/cordova-plugins/network-information.html'
			},
			{
				path: '/social-sharing',
				componentUrl: './partials/cordova-plugins/social-sharing.html'
			},
			{
				path: '/splash-screen',
				componentUrl: './partials/cordova-plugins/splash-screen.html'
			},
			{
				path: '/status-bar',
				componentUrl: './partials/cordova-plugins/status-bar.html'
			},
			{
				path: '/vibration',
				componentUrl: './partials/cordova-plugins/vibration.html'
			}
		]
	},
	{
		path: '/integrations',
		componentUrl: './partials/integrations.html',
		routes: [
			{
				path: '/algolia-places',
				componentUrl: './partials/integrations/algolia-places.html',
				beforeEnter: function(routeTo, routeFrom, resolve, reject) {
					app.preloader.show();
					if (window.places && window.L) {
						app.preloader.hide();
						resolve();
					}
					else {
						LazyLoad.css(['https://cdn.jsdelivr.net/leaflet/1/leaflet.css'], function() {
							LazyLoad.js(['https://cdn.jsdelivr.net/leaflet/1/leaflet.js'], function() {
								LazyLoad.js(['https://cdn.jsdelivr.net/npm/places.js'], function() {
									app.preloader.hide();
									resolve();
								});
							});
						});
					}
				}
			},
			{
				path: '/embedly',
				componentUrl: './partials/integrations/embedly.html',
				beforeEnter: function(routeTo, routeFrom, resolve, reject) {
					app.preloader.show();
					if (window.embedly) {
						app.preloader.hide();
						resolve();
					}
					else {
						LazyLoad.js(['https://cdn.embedly.com/widgets/platform.js'], function() {
							app.preloader.hide();
							resolve();
						});
					}
				}
			},
			{
				path: '/google-maps',
				componentUrl: './partials/integrations/google-maps.html',
				beforeEnter: function(routeTo, routeFrom, resolve, reject) {
					app.preloader.show();
					if (window.google && window.google.maps) {
						app.preloader.hide();
						resolve();
					}
					else {
						var language = app.utils.i18n.getLanguage();
						LazyLoad.js(['https://maps.googleapis.com/maps/api/js?key=' + app.data.config.googleMaps.apiKey + '&language=' + language.lang + '&libraries=places'], function() {
							app.preloader.hide();
							resolve();
						});
					}
				}
			},
			{
				path: '/google-amp',
				componentUrl: './partials/integrations/google-amp.html',
				beforeEnter: function(routeTo, routeFrom, resolve, reject) {
					app.preloader.show();
					if (window.AMP) {
						app.preloader.hide();
						resolve();
					}
					else {
						LazyLoad.js(['https://cdn.ampproject.org/shadow-v0.js'], function() {
							app.preloader.hide();
							resolve();
						});
					}
				}
			},
			{
				path: '/gravatar',
				componentUrl: './partials/integrations/gravatar.html'
			},
			{
				path: '/mailchimp',
				componentUrl: './partials/integrations/mailchimp.html'
			}
		]
	},
	{
		path: '/utilities',
		componentUrl: './partials/utilities.html',
		routes: [
			{
				path: '/brand-icons',
				componentUrl: './partials/utilities/brand-icons.html'
			},
			{
				path: '/colors',
				componentUrl: './partials/utilities/colors.html'
			},
			{
				path: '/dropcaps',
				componentUrl: './partials/utilities/dropcaps.html'
			},
			{
				path: '/elevation',
				componentUrl: './partials/utilities/elevation.html'
			},
			{
				path: '/embeds',
				componentUrl: './partials/utilities/embeds.html'
			},
			{
				path: '/line-dividers',
				componentUrl: './partials/utilities/line-dividers.html'
			}
		]
	},
	{
		path: '/more',
		componentUrl: './partials/more.html'
	},
	{
		path: '(.*)',
		componentUrl: './partials/screens/404.html'
	}
];

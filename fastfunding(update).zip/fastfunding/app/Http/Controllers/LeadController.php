<?php

namespace App\Http\Controllers;

use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Mail\Mailer;
use Illuminate\Mail\Message;
use Validator;
use App\Lead;

class LeadController extends Controller
{
    protected $admin_email = 'info@24hrfastfunding.com';
    protected $mailer;

    public function __construct(Mailer $mailer)
    {
        $this->middleware('auth');
        $this->mailer = $mailer;

        $admin = User::where('activated', true)->where('permission', 5)->get();
        if ($admin->count()){
            $this->admin_email = $admin[0]->email;
        }
    }

    public function index(){
        if (Auth()->user()['permission'] > 4)
            return redirect('/');
        return view('addLead');
    }

    public function addLead(Request $request){

        $validator = $this->validator($request->all());

        if ($validator->fails()) {
            return redirect('/add')->with('status_failed', 'The lead was already added!');
        }

        $lead = $this->createLead($request->all());

        $like_contact_way = 'The client would like to be contacted by his email.';
        switch ($request->input('radio')){
            case 2:
                $like_contact_way = 'The client would like to be contacted by Text.';
                break;
            case 3:
                $like_contact_way = 'The client would like to be contacted by Call.';
                break;
            case 4:
                $like_contact_way = 'The client would like to be contacted by Any way.';
                break;
            case 5:
                $like_contact_way = 'Client will contact when ready.';
                break;
            default:
                $like_contact_way = 'The client would like to be contacted by his email.';
                break;

        }

        // Send mail
        $message_name = sprintf(' <p style="color: blue">%s</p>', 'Name'.$request->input('first_name').' '.$request->input('last_name'));
        $message_phone = sprintf(' <p style="color: lightskyblue">%s</p>', 'Phone: '.$request->input('mo_number'));
        $message_email = sprintf(' <p style="color: lightskyblue">%s</p>', 'Email: '.$request->input('email'));
        $message_memo = sprintf(' <p style="color: black">%s</p>', 'Information: '.$request->input('memo'));
        $message_like = sprintf(' <p style="color: darkred">%s</p>',$like_contact_way);

        $message = $message_name.$message_phone.$message_email.$message_memo.$message_like;

        $this->mailer->raw($message, function (Message $m) use ($request) {
            $m->from(Auth()->user()->email)->to($this->admin_email)->subject('New Lead!');
        });
        // End sendmail

        if ($lead)
            return redirect('/add')->with('status_success', 'New lead is added.');
        return redirect('/add')->with('status_failed', 'Unknown Error!');
    }

    public function updateStage(Request $request) {
        $lead = Lead::findOrNew($request->input('id'));
        $lead->status = $request->input('value');

        $now = Carbon::now();
        if ($request->input('value') == 7 || $request->input('value') == 6)
            $lead->payout_date = $now->year.'-'.$now->month.'-'.$now->day;
        else
            $lead->payout_date = '';
        $lead->save();

        return Carbon::now();
    }

    protected function validator(array $data)
    {

        return Validator::make($data, [
            'last_name' => 'required|max:255',
            'first_name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:leads',
            'mo_number' => 'required|unique:leads'
        ]);
    }

    protected function createLead(array $data)
    {

        return Lead::create([
            'first_name' => $data['first_name'],
            'last_name' => $data['last_name'],
            'affiliate_id'=>Auth()->user()['id'],
            'email' => $data['email'],
            'mo_number' => $data['mo_number'],
            'payout_date' => '',
        ]);
    }



    public function goIssue(){

        if (Auth()->user()['permission'] > 4)
            return redirect('/');

        $admin = User::where('activated', true)->where('permission', 5)->get();
        $admin_phone = '';
        if ($admin->count()){
            $admin_phone = $admin[0]->mo_number;
            $this->admin_email = $admin[0]->email;
        }

        return view('issue', [
            'admin_phone'=>$admin_phone
        ]);
    }

    public function postIssue(Request $request){
        $memo = $request->input('memo');

        // Send mail
        $message_memo = sprintf(' <p style="color: black">%s</p>','MY ISSUE: '.$memo);
        $this->mailer->raw($message_memo, function (Message $m) use ($request) {
            $m->from($request->input('email'))->to($this->admin_email)->subject('My Issue');
        });

        return redirect('/issue')->with('issue_success', 'You sent Administrator your issue.');
    }
}

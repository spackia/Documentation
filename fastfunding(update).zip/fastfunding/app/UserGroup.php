<?php
namespace App;

/******************************************************
 * IM - Vocabulary Builder
 * Version : 1.0.2
 * Copyright© 2016 24hrfastfunding Ltd. All Rights Reversed.
 * This file may not be redistributed.
 * Author URL:http://24hrfastfunding.net
 ******************************************************/

use Illuminate\Database\Eloquent\Model;
use App\Word;

class UserGroup extends Model
{
	protected $fillable = ['name'];
}

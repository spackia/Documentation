<style>
    .parsley-errors-list {
        width: 100% !important;
    }
</style>
<?php $__env->startSection('content'); ?>

    <!-- Log In page -->
    <div class="row vh-100">
        <div class="col-lg-3  pr-0">
            <div class="card mb-0 shadow-none">
                <div class="card-body">

                    <div class="px-3">
                        <div class="media">
                            <a href="<?php echo e(url('/')); ?>" class="logo logo-admin">
                                <img src="<?php echo e(asset('assets/images/logo-light.png')); ?>" height="35" width="150" alt="logo" class="my-3">
                            </a>
                        </div>
                        <?php if($errors->first() == "active" or session('status')): ?>
                            <div class="alert alert-outline-warning alert-warning-shadow mb-0 alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true"><i class="mdi mdi-close"></i></span>
                                </button>
                                <strong>Warning:</strong> We sent you an activation code. Check your email.
                            </div>

                        <?php elseif($errors->first() == "error"): ?>
                            <div class="alert alert-outline-danger alert-danger-shadow mb-0 alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true"><i class="mdi mdi-close"></i></span>
                                </button>
                                <strong>Error:</strong> Your email and password are wrong.
                            </div>
                        <?php else: ?>
                            <div class="alert alert-outline-success alert-success-shadow mb-0 alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true"><i class="mdi mdi-close"></i></span>
                                </button>
                                <strong>SUCCESS:</strong> You have successfully logged in! Redirecting to home...
                            </div>
                        <?php endif; ?>

                        <form class="form-horizontal my-4" method="POST" action="<?php echo e(url('/login')); ?>">

                            <div class="form-group">
                                <label for="username">Email</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="mdi mdi-account-outline font-16"></i></span>
                                    </div>
                                    <input type="email" class="form-control" name="email" id="email" required parsley-type="email" placeholder="Enter email">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="password">Password</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon2"><i class="mdi mdi-key font-16"></i></span>
                                    </div>
                                    <input type="password" class="form-control" name="password" required id="password" placeholder="Enter password">
                                </div>
                            </div>

                            <div class="form-group row mt-4">
                                <div class="col-sm-6">
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" name="rememberme" id="customControlInline">
                                        <label class="custom-control-label" for="customControlInline">Remember me</label>
                                    </div>
                                </div>
                                <div class="col-sm-6 text-right d-none">
                                    <a href="pages-recoverpw-2.html" class="text-muted font-13"><i class="mdi mdi-lock"></i> Forgot your password?</a>
                                </div>
                            </div>

                            <div class="form-group mb-0 row">
                                <div class="col-12 mt-2">
                                    <button class="btn btn-login btn-primary btn-block waves-effect waves-light" type="submit">Log In <i class="fas fa-sign-in-alt ml-1"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="m-3 text-center bg-light p-3 text-primary">
                        <h5 class="">Don't have an account ? </h5>
                        <p class="font-13">Join <span>24hr Fast Funding Capital</span> Now</p>
                        <a href="<?php echo e(url('/register')); ?>" class="btn btn-primary btn-round waves-effect waves-light">Resister</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-9 p-0 d-flex justify-content-center">
            <div class="accountbg d-flex align-items-center">
                <div class="account-title text-white text-center">
                    <img src="<?php echo e(asset('assets/images/logo-light.png')); ?>" height="40" width="175" alt="" >
                    <h4 class="mt-3">Welcome To 24hr Fast Funding Capital</h4>
                    <div class="border w-25 mx-auto border-primary"></div>
                    <h2 class="">Let's Get Started</h2>
                    <p class="font-14 mt-3">Don't have an account ? <a href="<?php echo e(url('/register')); ?>" class="text-primary">Sign up</a></p>

                </div>
            </div>
        </div>
    </div>
    <!-- End Log In page -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>
    <script>
        $('.alert-outline-success').removeAttr("style").hide();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.authapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
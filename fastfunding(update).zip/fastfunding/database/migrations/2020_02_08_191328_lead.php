<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Lead extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('leads', function (Blueprint $table) {
            $table->increments('id');
            $table->string('affiliate_id');
            $table->string('first_name');
            $table->string('last_name');
            $table->string('email');
            $table->string('mo_number');
            /*
             * 0-Lead received, 1-Reached out to client, 2-Client submitted application,
             * 3-Underwriting, 4-loan approved, 5-loan rejected, 6-funded, 7 - Payout sent to affiliate
             *
             */
            $table->integer('status')->default(0);
            $table->string('payout_date');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('leads');
    }
}

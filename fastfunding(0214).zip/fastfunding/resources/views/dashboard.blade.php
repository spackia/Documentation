@extends('layouts.app')

@section('css')
    <!-- DataTables -->
    <link href="{{asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('assets/plugins/datatables/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />
@endsection

<style>
    .modal-backdrop.show {
        z-index: 99;
    }
</style>

@section('content')
    <!-- Top Bar Start -->
    <div class="topbar">
        <!-- Navbar -->
        <nav class="navbar-custom">

            <!-- LOGO -->
            <div class="topbar-left mt-3">
                <a href="{{url('/')}}" class="logo">
                        <span>
                            <img src="{{asset('assets/images/logo-light.png')}}" alt="logo-large" style="height: 30px;" class="logo-lg">
                        </span>
                </a>
            </div>

            <ul class="list-unstyled topbar-nav float-right mb-0">

                <li class="dropdown">
                    <a class="nav-link dropdown-toggle waves-effect waves-light nav-user" data-toggle="dropdown" href="#" role="button"
                       aria-haspopup="false" aria-expanded="false">
                        <img src="{{asset('assets/images/users/user-1.jpg')}}" alt="profile-user" class="rounded-circle img-thumbnail mb-1"/>
                        <span class="online-icon" style="margin-left: -10px"><i class="mdi mdi-record text-success"></i></span>
                        <span class="ml-1 nav-user-name hidden-sm">
                            @if(Auth()->user()['permission'] > 4)
                                Admin
                            @else
                                {{Auth()->user()['first_name']}} {{Auth()->user()['last_name']}}
                            @endif

                            <i class="mdi mdi-chevron-down"></i>
                        </span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="#"><i class="dripicons-user text-muted mr-2"></i> Profile</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" data-toggle="modal" data-animation="bounce" data-target=".bs-logout-modal-sm" href="">
                            <i class="dripicons-exit text-muted mr-2"></i> Logout</a>
                    </div>
                    <div class="modal fade bs-logout-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-sm">
                            <div class="modal-content">
                                <div class="modal-body" style="text-align: center">
                                    <h4 class="mt-2" style="text-align: center;color: white">Are you sure?</h4>
                                    <button type="button" class="btn btn-danger mt-2">
                                        <a href="{{url('/signout')}}" style="color: white">Yes, Logout</a>
                                    </button>
                                    <button type="button" class="btn btn-outline-light mt-2" data-dismiss="modal">
                                        Cancel
                                    </button>
                                </div>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->
                </li>
                <li class="menu-item">
                    <!-- Mobile menu toggle-->
                    <a class="navbar-toggle nav-link" id="mobileToggle">
                        <div class="lines">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </a>
                    <!-- End mobile menu toggle-->
                </li>
            </ul>

        </nav>
        <!-- end navbar-->
    </div>
    <!-- Top Bar End -->
    <div class="page-wrapper-img" style="min-height: 111px">
        <div class="page-wrapper-img-inner d-none">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box ml-0">
                        <h4 class="page-title mb-2">
                            <i class="mdi mdi-monitor mr-2"></i>
                            @if(Auth()->user()['permission'] > 4)
                                Leads
                            @else
                                Leads
                            @endif
                        </h4>
                        <div class="d-none">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item active">
                                    @if(Auth()->user()['permission'] > 4)
                                        Leads
                                    @endif
                                </li>
                            </ol>
                        </div>
                    </div><!--end page title box-->
                </div><!--end col-->
            </div><!--end row-->
            <!-- end page title end breadcrumb -->
        </div><!--end page-wrapper-img-inner-->
    </div><!--end page-wrapper-img-->

    <div class="page-wrapper min-vh-100">
        <div class="page-wrapper-inner">

            <!-- Navbar Custom Menu -->
            <div class="navbar-custom-menu">

                <div class="container-fluid">
                    <div id="navigation">
                        <!-- Navigation Menu-->
                        <ul class="navigation-menu list-unstyled">

                            @if(Auth()->user()['permission'] > 4)
                                <li class="has-submenu active">
                                    <a href="{{url('/')}}">
                                        <i class="mdi mdi-view-list"></i>
                                        Leads
                                    </a>
                                </li>
                                <li class="has-submenu">
                                    <a href="{{url('/users')}}">
                                        <i class="mdi mdi-view-list"></i>
                                        Affiliate
                                    </a>
                                </li>
                            @else
                                <li class="has-submenu active">
                                    <a href="{{url('/')}}">
                                        <i class="mdi mdi-view-list"></i>
                                        Leads
                                    </a>
                                </li>
                                <li class="has-submenu">
                                    <a href="{{url('/add')}}">
                                        <i class="mdi mdi-account"></i>
                                        Add New Lead
                                    </a>
                                </li>
                                <li class="has-submenu">
                                    <a href="{{url('/issue')}}">
                                        <i class="mdi mdi-contact-mail"></i>
                                        Issues
                                    </a>
                                </li>
                            @endif

                        </ul>
                        <!-- End navigation menu -->
                    </div> <!-- end navigation -->
                </div> <!-- end container-fluid -->
            </div>
            <!-- end left-sidenav-->
        </div>
        <!--end page-wrapper-inner -->
        <!-- Page Content-->
        <div class="page-content">
            <div class="container-fluid">
                @if(Auth()->user()['permission'] < 4)
                <div class="row">
                    <div class="col-lg-2"></div>
                    <div class="col-lg-4">
                        <div class="card carousel-bg-img">
                            <div class="card-body dash-info-carousel mb-0">
                                <div class="row">
                                    <div class="col-12 align-self-center">
                                        <div class="text-center">
                                            <h4 class="mt-0 header-title text-left">Revenue</h4>
                                            <div class="icon-info my-3">
                                                <i class="dripicons-jewel bg-soft-pink"></i>
                                            </div>
                                            <h2 class="mt-0 font-weight-bold text-success">${{$revenue}}</h2>
                                            <p class="mb-1 text-muted">
                                                <span class="text-success">Accrued This Period</span>
                                            </p>
                                            <div class="row">
                                                <div class="col-lg-1"></div>
                                                <div class="col-lg-5 mr-0 p-0">
                                                    <button class="btn btn-success waves-effect waves-light mw-100 w-100 p-0" type="button" style="border-radius: 10px 0 0 10px">This Period</button>
                                                </div>
                                                <div class="col-lg-5 ml-0 p-0">
                                                    <button class="btn btn-secondary waves-effect waves-light mw-100 w-100 p-0" type="button" style="border-radius: 0 10px 10px 0">Total</button>
                                                </div>
                                                <div class="col-lg-1"></div>
                                            </div>
                                        </div>
                                    </div><!--end col-->
                                </div><!--end row-->
                            </div><!--end card-body-->
                        </div><!--end card-->
                    </div><!--end col-->
                    <div class="col-lg-4">
                        <div class="card carousel-bg-img">
                            <div class="card-body dash-info-carousel mb-0">
                                <div class="row">
                                    <div class="col-12 align-self-center">
                                        <div class="text-center">
                                            <h4 class="mt-0 header-title text-left">Deposite</h4>
                                            <div class="icon-info my-3">
                                                <i class="dripicons-jewel bg-soft-pink"></i>
                                            </div>
                                            <h2 class="mt-0 font-weight-bold text-purple">${{$deposit}}</h2>
                                            <p class="mb-1 text-muted">
                                                <span class="text-purple">
                                                    @if($deposit_date != '')
                                                        Will be deposited on {{$deposit_date}}
                                                    @else
                                                        Will be deposited on
                                                    @endif
                                                </span>
                                            </p>
                                            <div class="row invisible">
                                                <div class="col-lg-1"></div>
                                                <div class="col-lg-5 mr-0 p-0">
                                                    <button class="btn btn-success waves-effect waves-light mw-100 w-100 p-0" type="button" style="border-radius: 10px 0 0 10px">This Period</button>
                                                </div>
                                                <div class="col-lg-5 ml-0 p-0">
                                                    <button class="btn btn-secondary waves-effect waves-light mw-100 w-100 p-0" type="button" style="border-radius: 0 10px 10px 0">Total</button>
                                                </div>
                                                <div class="col-lg-1"></div>
                                            </div>
                                        </div>
                                    </div><!--end col-->
                                </div><!--end row-->
                            </div><!--end card-body-->
                        </div><!--end card-->
                    </div><!--end col-->
                    <div class="col-lg-2"></div>
                </div><!--end Reposit-->
                @endif
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <div class="card">
                           <div class="card-body table-responsive">
                              <div class="">
                                  <table id="lead_datatable" class="table dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                       <thead>
                                           <tr>
                                               <th>Client</th>
                                               <th>Date submitted</th>
                                               <th>Days in System</th>
                                               <th>Lead Stage</th>
                                               @if(Auth()->user()['permission'] > 4)
                                                   <th>Affiliate</th>
                                               @endif
                                               <th>Payout Amount</th>
                                               <th>Payout Date</th>
                                           </tr>
                                       </thead>
                                       <tbody>
                                       @foreach ($leads as $lead)
                                           <tr>
                                               <td>{{$lead->first_name}} {{$lead->last_name}}</td>
                                               <td>{{$lead->created_at->format('M-d-Y')}}</td>
                                               <td>{{$lead->created_at->diffForHumans(null, $today).' '}}</td>
                                               <td>
                                                   @if(Auth()->user()['permission'] > 4)
                                                   <select class="form-control" onchange="updateStatus({{$lead->id}}, this)" >
                                                       <option value="0" @if($lead->status == 0) selected @endif>Lead received</option>
                                                       <option value="1" @if($lead->status == 1) selected @endif>Reached out to client</option>
                                                       <option value="2" @if($lead->status == 2) selected @endif>Client submitted application</option>
                                                       <option value="3" @if($lead->status == 3) selected @endif>Underwriting</option>
                                                       <option value="4" @if($lead->status == 4) selected @endif>Loan approved</option>
                                                       <option value="5" @if($lead->status == 5) selected @endif>Loan rejected</option>
                                                       <option value="6" @if($lead->status == 6) selected @endif>Funded</option>
                                                       <option value="7" @if($lead->status == 7) selected @endif>Payout sent to affiliate</option>
                                                   </select>
                                                   @endif
                                                   @if(Auth()->user()['permission'] < 4)
                                                       @if($lead->status == 0)Lead received
                                                       @elseif($lead->status == 1)Reached out to client
                                                       @elseif($lead->status == 2)Client submitted application
                                                       @elseif($lead->status == 3)Underwriting
                                                       @elseif($lead->status == 4)Loan approved
                                                       @elseif($lead->status == 5)Loan rejected
                                                       @elseif($lead->status == 6)Funded
                                                       @elseif($lead->status == 7)Payout sent to affiliate
                                                       @endif
                                                   @endif
                                               </td>
                                               @if(Auth()->user()['permission'] == 5)
                                                   <td>
                                                       <span>{{$lead->users[0]['first_name']}} {{$lead->users[0]['last_name']}}</span>
                                                   </td>
                                               @endif
                                               <td>
                                                   <span id="amount_{{$lead->id}}">
                                                   @if($lead->status == 4 or $lead->status == 6 or $lead->status == 7)
                                                       $500
                                                   @else
                                                       N/A
                                                   @endif
                                                   </span>
                                               </td>
                                               <td>
                                                   <span id="payout_date_{{$lead->id}}">
                                                   @if($lead->status == 7 && $lead->payout_date != '')
                                                       {{$lead->payout_date}}
                                                   @else
                                                       N/A
                                                   @endif
                                                   </span>
                                               </td>
                                           </tr>
                                       @endforeach
                                       </tbody>
                                   </table>
                              </div>
                           </div>
                        </div>
                    </div>
                </div><!--end row-->

            </div><!-- container -->

            <footer class="footer text-center text-sm-left">
                &copy; 2020 24hr Fast Funding Capital
            </footer>
        </div>
        <!-- end page content -->
    </div>
    <!-- end page-wrapper -->
@endsection

@section('script')
    <script src="{{asset('assets/plugins/tiny-editable/mindmup-editabletable.js')}}"></script>
    <script src="{{asset('assets/plugins/tiny-editable/numeric-input-example.js')}}"></script>
    <!-- Required datatable js -->
    <script src="{{asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
    <!-- Buttons examples -->
    <script src="{{asset('assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
    <script src="{{asset('assets/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
    <script src="{{asset('assets/pages/jquery.datatable.init.js')}}"></script>
    <script>
        function  updateStatus(id, selectObject) {
            $.ajax({
                url:'/index.php/leads/edit/stage',
                type:'post',
                data: {
                    'value': selectObject.value,
                    'id': id,
                    '_token': '{!! csrf_token() !!}'
                },
                success: function(res) {
                    var d = new Date();
                    var date = d.getDate();
                    if (date < 10) date = '0' + date;
                    var month = d.getMonth() + 1;
                    if (month < 10) month = '0' + month;
                    var year = d.getFullYear();
                    var dateStr = year + "-" + month + "-" + date;

                    if (selectObject.value == 4 || selectObject.value == 6 || selectObject.value == 7)
                        $('#amount_'+id).text('$500');
                    else
                        $('#amount_'+id).text('N/A');
                    if (selectObject.value == 7)
                        $('#payout_date_'+id).text(dateStr);
                    else $('#payout_date_'+id).text('N/A');
                },
                error: function (res) {
                    console.log('failure')
                }
            });
        }

        $(document).ready(function() {

            $(document).ready(function() {
                $('#lead_datatable').DataTable();
            } );
        } );
    </script>
@endsection

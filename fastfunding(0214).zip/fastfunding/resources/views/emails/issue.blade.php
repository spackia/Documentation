<?php
/**
 * Created by PhpStorm.
 * User: MA
 * Date: 2020-02-13
 * Time: 11:33 AM
 */
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>My Issue!</title>
</head>
<body>
<p style="color: black">{{$issue}}</p>
</body>
</html>

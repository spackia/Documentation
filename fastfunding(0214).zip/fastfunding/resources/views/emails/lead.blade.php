<?php
/**
 * Created by PhpStorm.
 * User: MA
 * Date: 2020-02-13
 * Time: 11:16 AM
 */
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>New Lead!</title>
</head>
<body>
    <h3>New Lead!</h3>
    <p style="color: blue">Name: {{$name}}</p>
    <p style="color: lightskyblue">Phone: {{$phone}}</p>
    <p style="color: lightskyblue">Email: {{$email}}</p>
    <p style="color: black">Information: {{$info}}</p>
    <p style="color: black">* {{$like_contact_way}}</p>
</body>
</html>

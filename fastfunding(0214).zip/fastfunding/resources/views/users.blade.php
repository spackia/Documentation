@extends('layouts.app')

@section('css')
    <!-- DataTables -->
    <link href="{{asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('assets/plugins/datatables/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />
@endsection

<style>
    .modal-backdrop.show {
        z-index: 99;
    }
</style>

@section('content')
    <!-- Top Bar Start -->
    <div class="topbar">
        <!-- Navbar -->
        <nav class="navbar-custom">

            <!-- LOGO -->
            <div class="topbar-left mt-3">
                <a href="{{url('/')}}" class="logo">
                        <span>
                            <img src="{{asset('assets/images/logo-light.png')}}" alt="logo-large" style="height: 30px;" class="logo-lg">
                        </span>
                </a>
            </div>

            <ul class="list-unstyled topbar-nav float-right mb-0">

                <li class="dropdown">
                    <a class="nav-link dropdown-toggle waves-effect waves-light nav-user" data-toggle="dropdown" href="#" role="button"
                       aria-haspopup="false" aria-expanded="false">
                        <img src="{{asset('assets/images/users/user-1.jpg')}}" alt="profile-user" class="rounded-circle img-thumbnail mb-1"/>
                        <span class="online-icon" style="margin-left: -10px"><i class="mdi mdi-record text-success"></i></span>
                        <span class="ml-1 nav-user-name hidden-sm">
                            @if(Auth()->user()['permission'] > 4)
                                Admin
                            @endif

                            <i class="mdi mdi-chevron-down"></i>
                        </span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="#"><i class="dripicons-user text-muted mr-2"></i> Profile</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" data-toggle="modal" data-animation="bounce" data-target=".bs-logout-modal-sm" href="">
                            <i class="dripicons-exit text-muted mr-2"></i> Logout</a>
                    </div>
                    <div class="modal fade bs-logout-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-sm">
                            <div class="modal-content">
                                <div class="modal-body" style="text-align: center">
                                    <h4 class="mt-2" style="text-align: center;color: white">Are you sure?</h4>
                                    <button type="button" class="btn btn-danger mt-2">
                                        <a href="{{url('/signout')}}" style="color: white">Yes, Logout</a>
                                    </button>
                                    <button type="button" class="btn btn-outline-light mt-2" data-dismiss="modal">
                                        Cancel
                                    </button>
                                </div>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->
                </li>
                <li class="menu-item">
                    <!-- Mobile menu toggle-->
                    <a class="navbar-toggle nav-link" id="mobileToggle">
                        <div class="lines">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </a>
                    <!-- End mobile menu toggle-->
                </li>
            </ul>

        </nav>
        <!-- end navbar-->
    </div>
    <!-- Top Bar End -->
    <div class="page-wrapper-img" style="min-height: 111px">
        <div class="page-wrapper-img-inner d-none">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box ml-0">
                        <h4 class="page-title mb-2">
                            <i class="mdi mdi-monitor mr-2"></i>
                            @if(Auth()->user()['permission'] > 4)
                                Leads
                            @else
                                Leads
                            @endif
                        </h4>
                        <div class="d-none">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item active">
                                    @if(Auth()->user()['permission'] > 4)
                                        Leads
                                    @endif
                                </li>
                            </ol>
                        </div>
                    </div><!--end page title box-->
                </div><!--end col-->
            </div><!--end row-->
            <!-- end page title end breadcrumb -->
        </div><!--end page-wrapper-img-inner-->
    </div><!--end page-wrapper-img-->

    <div class="page-wrapper min-vh-100">
        <div class="page-wrapper-inner">

            <!-- Navbar Custom Menu -->
            <div class="navbar-custom-menu">

                <div class="container-fluid">
                    <div id="navigation">
                        <!-- Navigation Menu-->
                        <ul class="navigation-menu list-unstyled">

                            @if(Auth()->user()['permission'] > 4)
                                <li class="has-submenu">
                                    <a href="{{url('/')}}">
                                        <i class="mdi mdi-view-list"></i>
                                        Leads
                                    </a>
                                </li>
                                <li class="has-submenu active">
                                    <a href="{{url('/users')}}">
                                        <i class="mdi mdi-view-list"></i>
                                        Affiliate
                                    </a>
                                </li>
                            @endif

                        </ul>
                        <!-- End navigation menu -->
                    </div> <!-- end navigation -->
                </div> <!-- end container-fluid -->
            </div>
            <!-- end left-sidenav-->
        </div>
        <!--end page-wrapper-inner -->
        <!-- Page Content-->
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <div class="card">
                            <div class="card-body table-responsive">
                                <div class="">
                                    <table id="lead_datatable" class="table dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                        <tr>
                                            <th>Affiliate Name</th>
                                            <th>Date Joined</th>
                                            <th>Email</th>
                                            <th>Company Name</th>
                                            <th>Phone</th>
                                            <th>Delete</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach ($users as $user)
                                            <tr>
                                                <td>{{$user->first_name}} {{$user->last_name}}</td>
                                                <td>{{$user->created_at->format('M-d-Y')}}</td>
                                                <td>{{$user->email}}</td>
                                                <td>{{$user->company_name}}</td>
                                                <td>{{$user->mo_number}}</td>
                                                <td>
                                                    <?php $str_id = "modal_".$user->id ?>
                                                    <i class="fas fa-trash" data-toggle="modal" data-animation="bounce" data-target=".{{$str_id}}"></i>
                                                    <div class="modal fade {{$str_id}}" tabindex="-1" role="dialog" aria-hidden="true">
                                                        <div class="modal-dialog modal-md">
                                                            <div class="modal-content">
                                                                <div class="modal-body" style="text-align: center">
                                                                    <h4 class="mt-2" style="text-align: center;color: white">Are you going to delete {{$user->first_name}} {{$user->last_name}}'s account?</h4>
                                                                    <button type="button" class="btn btn-danger mt-2" onclick="removeUsers({{$user->id}})">
                                                                        <a href="" style="color: white">Yes</a>
                                                                    </button>
                                                                    <button type="button" class="btn btn-outline-light mt-2" data-dismiss="modal">
                                                                        Cancel
                                                                    </button>
                                                                </div>
                                                            </div><!-- /.modal-content -->
                                                        </div><!-- /.modal-dialog -->
                                                    </div><!-- /.modal -->
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!--end row-->

            </div><!-- container -->

            <footer class="footer text-center text-sm-left">
                &copy; 2020 24hr Fast Funding Capital
            </footer>
        </div>
        <!-- end page content -->
    </div>
    <!-- end page-wrapper -->
@endsection

@section('script')
    <script src="{{asset('assets/plugins/tiny-editable/mindmup-editabletable.js')}}"></script>
    <script src="{{asset('assets/plugins/tiny-editable/numeric-input-example.js')}}"></script>
    <!-- Required datatable js -->
    <script src="{{asset('assets/plugins/datatables/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')}}"></script>
    <!-- Buttons examples -->
    <script src="{{asset('assets/plugins/datatables/dataTables.buttons.min.js')}}"></script>
    <script src="{{asset('assets/plugins/datatables/buttons.bootstrap4.min.js')}}"></script>
    <script src="{{asset('assets/pages/jquery.datatable.init.js')}}"></script>
    <script>
        function  removeUsers(id) {
            $.ajax({
                url:'/index.php/user/delete',
                type:'post',
                data: {
                    'id': id,
                    '_token': '{!! csrf_token() !!}'
                },
                success: function(res) {
                    location.reload();
                },
                error: function (res) {

                }
            });
        }

        $(document).ready(function() {

            $(document).ready(function() {
                $('#lead_datatable').DataTable();
            } );
        } );
    </script>
@endsection

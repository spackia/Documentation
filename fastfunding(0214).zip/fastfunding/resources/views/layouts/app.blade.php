<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>{{ Config::get('SITE_TITLE') }}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A premium admin dashboard template by mannatthemes" name="description" />
    <meta content="Mannatthemes" name="author" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="{{asset('assets/images/logo_icon.png')}}">

    {{--<link href="{{asset('assets/plugins/jvectormap/jquery-jvectormap-2.0.2.css')}}" rel="stylesheet">--}}

    <!-- App css -->
    <link href="{{asset('assets/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('assets/css/icons.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('assets/css/metismenu.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('assets/css/style.css')}}" rel="stylesheet" type="text/css" />

    @yield('css')

</head>

<body>


@yield('content')


<!-- Scripts -->
<!-- jQuery  -->
<script src="{{asset('assets/js/jquery.min.js')}}"></script>
<script src="{{asset('assets/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('assets/js/metisMenu.min.js')}}"></script>
<script src="{{asset('assets/js/waves.min.js')}}"></script>
<script src="{{asset('assets/js/jquery.slimscroll.min.js')}}"></script>

{{--<script src="{{asset('assets/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js')}}"></script>--}}
{{--<script src="{{asset('assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js')}}"></script>--}}

<script src="{{asset('assets/plugins/moment/moment.js')}}"></script>
{{--<script src="{{asset('assets/plugins/apexcharts/apexcharts.min.js')}}"></script>--}}
{{--<script src="https://apexcharts.com/samples/assets/irregular-data-series.js"></script>--}}
{{--<script src="https://apexcharts.com/samples/assets/series1000.js"></script>--}}
{{--<script src="https://apexcharts.com/samples/assets/ohlc.js"></script>--}}
<script src="{{asset('assets/pages/jquery.dashboard.init.js')}}"></script>

<script src="{{asset('assets/plugins/custombox/custombox.min.js')}}"></script>
<script src="{{asset('assets/plugins/custombox/custombox.legacy.min.js')}}"></script>

<script src="{{asset('assets/pages/jquery.modal-animation.js')}}"></script>

@yield('script')
<script src="{{asset('assets/js/jquery.core.js')}}"></script>
<!-- App js -->
<script src="{{asset('assets/js/app.js')}}"></script>

</body>
</html>

<?php $__env->startSection('css'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<style>
    .modal-backdrop.show {
        z-index: 99;
    }
</style>

<?php $__env->startSection('content'); ?>
    <!-- Top Bar Start -->
    <div class="topbar">
        <!-- Navbar -->
        <nav class="navbar-custom">

            <!-- LOGO -->
            <div class="topbar-left mt-3">
                <a href="<?php echo e(url('/')); ?>" class="logo">
                        <span>
                            <img src="<?php echo e(asset('assets/images/logo-light.png')); ?>" alt="logo-large" style="height: 30px;" class="logo-lg">
                        </span>
                </a>
            </div>

            <ul class="list-unstyled topbar-nav float-right mb-0">

                <li class="dropdown">
                    <a class="nav-link dropdown-toggle waves-effect waves-light nav-user" data-toggle="dropdown" href="#" role="button"
                       aria-haspopup="false" aria-expanded="false">
                        <img src="<?php echo e(asset('assets/images/users/user-1.jpg')); ?>" alt="profile-user" class="rounded-circle img-thumbnail mb-1"/>
                        <span class="online-icon" style="margin-left: -10px"><i class="mdi mdi-record text-success"></i></span>
                        <span class="ml-1 nav-user-name hidden-sm">
                            <?php if(Auth()->user()['permission'] > 4): ?>
                                Admin
                            <?php endif; ?>

                            <i class="mdi mdi-chevron-down"></i>
                        </span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="#"><i class="dripicons-user text-muted mr-2"></i> Profile</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" data-toggle="modal" data-animation="bounce" data-target=".bs-logout-modal-sm" href="">
                            <i class="dripicons-exit text-muted mr-2"></i> Logout</a>
                    </div>
                    <div class="modal fade bs-logout-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-sm">
                            <div class="modal-content">
                                <div class="modal-body" style="text-align: center">
                                    <h4 class="mt-2" style="text-align: center;color: white">Are you sure?</h4>
                                    <button type="button" class="btn btn-danger mt-2">
                                        <a href="<?php echo e(url('/signout')); ?>" style="color: white">Yes, Logout</a>
                                    </button>
                                    <button type="button" class="btn btn-outline-light mt-2" data-dismiss="modal">
                                        Cancel
                                    </button>
                                </div>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->
                </li>
                <li class="menu-item">
                    <!-- Mobile menu toggle-->
                    <a class="navbar-toggle nav-link" id="mobileToggle">
                        <div class="lines">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </a>
                    <!-- End mobile menu toggle-->
                </li>
            </ul>

        </nav>
        <!-- end navbar-->
    </div>
    <!-- Top Bar End -->
    <div class="page-wrapper-img" style="min-height: 111px">
        <div class="page-wrapper-img-inner d-none">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box ml-0">
                        <h4 class="page-title mb-2">
                            <i class="mdi mdi-monitor mr-2"></i>
                            <?php if(Auth()->user()['permission'] > 4): ?>
                                Leads
                            <?php else: ?>
                                Leads
                            <?php endif; ?>
                        </h4>
                        <div class="d-none">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item active">
                                    <?php if(Auth()->user()['permission'] > 4): ?>
                                        Leads
                                    <?php endif; ?>
                                </li>
                            </ol>
                        </div>
                    </div><!--end page title box-->
                </div><!--end col-->
            </div><!--end row-->
            <!-- end page title end breadcrumb -->
        </div><!--end page-wrapper-img-inner-->
    </div><!--end page-wrapper-img-->

    <div class="page-wrapper min-vh-100">
        <div class="page-wrapper-inner">

            <!-- Navbar Custom Menu -->
            <div class="navbar-custom-menu">

                <div class="container-fluid">
                    <div id="navigation">
                        <!-- Navigation Menu-->
                        <ul class="navigation-menu list-unstyled">

                            <?php if(Auth()->user()['permission'] > 4): ?>
                                <li class="has-submenu">
                                    <a href="<?php echo e(url('/')); ?>">
                                        <i class="mdi mdi-view-list"></i>
                                        Leads
                                    </a>
                                </li>
                                <li class="has-submenu active">
                                    <a href="<?php echo e(url('/users')); ?>">
                                        <i class="mdi mdi-view-list"></i>
                                        Affiliate
                                    </a>
                                </li>
                            <?php endif; ?>

                        </ul>
                        <!-- End navigation menu -->
                    </div> <!-- end navigation -->
                </div> <!-- end container-fluid -->
            </div>
            <!-- end left-sidenav-->
        </div>
        <!--end page-wrapper-inner -->
        <!-- Page Content-->
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-sm-12">
                        <div class="card">
                            <div class="card-body table-responsive">
                                <div class="">
                                    <table id="lead_datatable" class="table dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead>
                                        <tr>
                                            <th>Affiliate Name</th>
                                            <th>Date Joined</th>
                                            <th>Email</th>
                                            <th>Company Name</th>
                                            <th>Phone</th>
                                            <th>Delete</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <tr>
                                                <td><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                                                <td><?php echo e($user->created_at->format('M-d-Y')); ?></td>
                                                <td><?php echo e($user->email); ?></td>
                                                <td><?php echo e($user->company_name); ?></td>
                                                <td><?php echo e($user->mo_number); ?></td>
                                                <td>
                                                    <?php $str_id = "modal_".$user->id ?>
                                                    <i class="fas fa-trash" data-toggle="modal" data-animation="bounce" data-target=".<?php echo e($str_id); ?>"></i>
                                                    <div class="modal fade <?php echo e($str_id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                                        <div class="modal-dialog modal-md">
                                                            <div class="modal-content">
                                                                <div class="modal-body" style="text-align: center">
                                                                    <h4 class="mt-2" style="text-align: center;color: white">Are you going to delete <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>'s account?</h4>
                                                                    <button type="button" class="btn btn-danger mt-2" onclick="removeUsers(<?php echo e($user->id); ?>)">
                                                                        <a href="" style="color: white">Yes</a>
                                                                    </button>
                                                                    <button type="button" class="btn btn-outline-light mt-2" data-dismiss="modal">
                                                                        Cancel
                                                                    </button>
                                                                </div>
                                                            </div><!-- /.modal-content -->
                                                        </div><!-- /.modal-dialog -->
                                                    </div><!-- /.modal -->
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!--end row-->

            </div><!-- container -->

            <footer class="footer text-center text-sm-left">
                &copy; 2020 24hr Fast Funding Capital
            </footer>
        </div>
        <!-- end page content -->
    </div>
    <!-- end page-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/plugins/tiny-editable/mindmup-editabletable.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/tiny-editable/numeric-input-example.js')); ?>"></script>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Buttons examples -->
    <script src="<?php echo e(asset('assets/plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/pages/jquery.datatable.init.js')); ?>"></script>
    <script>
        function  removeUsers(id) {
            $.ajax({
                url:'/index.php/user/delete',
                type:'post',
                data: {
                    'id': id,
                    '_token': '<?php echo csrf_token(); ?>'
                },
                success: function(res) {
                    location.reload();
                },
                error: function (res) {

                }
            });
        }

        $(document).ready(function() {

            $(document).ready(function() {
                $('#lead_datatable').DataTable();
            } );
        } );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
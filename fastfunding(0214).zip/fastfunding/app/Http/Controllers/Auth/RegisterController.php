<?php

namespace App\Http\Controllers\Auth;

use App\ActivationService;
use App\User;
use Illuminate\Http\Request;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\RegistersUsers;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;
    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
    protected $redirectTo = '/signout';

    //Add protected variable:
    protected $activationService;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(ActivationService $activationService)
    {
      //  $this->middleware('auth');
        $this->middleware('guest');
        $this->activationService = $activationService;
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {

        return Validator::make($data, [
            'last_name' => 'required|max:255',
            'first_name' => 'required|max:255',
            'company_name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'mo_number' => 'required',
            'password' => 'required|min:6',
          //  'g-recaptcha-response' => 'required|captcha'
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {

        return User::create([
            'last_name' => $data['last_name'],
            'first_name' => $data['first_name'],
            'company_name' => $data['company_name'],
            'email' => $data['email'],
            'mo_number' => $data['mo_number'],
            'password' => bcrypt($data['password']),
        ]);
    }

    public function register(Request $request)
    {
        $validator = $this->validator($request->all());

        if ($validator->fails()) {
//            $this->throwValidationException(
//                $request, $validator
//            );
            return redirect('/register')->with('signin', 'Already exist!');
        }

        $user = $this->create($request->all());

        $this->activationService->sendActivationMail($user);

        return redirect('/register')->with('signin', 'We sent you an activation code. Check your email.');
    }

    protected function CustomCaptcha(Request $request) {

    }
}

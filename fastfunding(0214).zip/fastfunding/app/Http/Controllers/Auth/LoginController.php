<?php

namespace App\Http\Controllers\Auth;

use App\ActivationService;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Redirect;
use Input;
use App\User;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */
    use AuthenticatesUsers;

    //Add protected variable:
    protected $activationService;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(ActivationService $activationService)
    {
      //  $this->middleware('guest', ['except' => 'logout']);
        $this->activationService = $activationService;
    }

    public function activateUser($token)
    {
        if ($user = $this->activationService->activateUser($token)) {
            auth()->login($user);
            return redirect($this->redirectPath());
        }
        abort(404);
    }

    public function login(Request $request)
    {
        $this->validate($request, [
            'email' => 'required|email',
            'password' => 'required',
        ]);
        $rememberme = true;

        if ($request->input('rememberme') == 'on')
            $rememberme = true;
        else
            $rememberme = false;

        if (auth()->attempt(array('email' => $request->input('email'), 'password' => $request->input('password')), $rememberme))
        {
            if(auth()->user()->activated == false){
                $this->logout($request);
                return Redirect::back()->with('warning',"We sent you an activation code. Check your email.");
            }

            if(auth()->user()->permission == -1){
                $this->logout($request);
                return Redirect::back()->with('error',"Your account has been closed.");
            }

            if (auth()->user()->permission = 5)
            {
                return redirect()->to('/');
            }

            return redirect()->to('/');
        }else{

            return Redirect::back()->with('error','Your email and password are wrong.');
        }
    }
}

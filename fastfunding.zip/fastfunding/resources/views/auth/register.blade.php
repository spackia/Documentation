@extends('layouts.authapp')
<style>
    .g-recaptcha div {
        margin-left: -15px;
    }

    .parsley-errors-list {
        width: 100% !important;
    }

</style>
@section('content')

    <!-- Log In page -->
    <div class="row vh-100">
        <div class="col-lg-3  pr-0">
            <div class="card mb-0 shadow-none">
                <div class="card-body">

                    <div class="px-3">
                        <div class="media d-none">
                            <a href="{{url('/home')}}" class="logo logo-admin"><img src="{{asset('assets/images/logo-light.png')}}" height="35" width="150" alt="logo" class="my-3"></a>
                            <div class="media-body ml-3 align-self-center">
                                <h4 class="mt-0 mb-1">Register for 24hr Fast Funding Capital</h4>
                                <p class="text-muted mb-0">Get your free 24hr Fast Funding Capital account now.</p>
                            </div>
                        </div>

                        <form class="form-horizontal my-4" role="form" method="POST" action="{{ url('/register') }}">

                            @if(session('signin'))
                                <div class="alert alert-outline-warning alert-warning-shadow mb-0 alert-dismissible fade show" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true"><i class="mdi mdi-close"></i></span>
                                    </button>
                                    <strong>Warning:</strong> {{session('signin')}}
                                </div>
                            @endif
                            <div class="form-group">
                                <label class="d-none" for="first_name">First Name</label>
                                <div class="input-group mb-3">
                                      <div class="input-group-prepend">
                                          <span class="input-group-text" id="basic-addon1"><i class="mdi mdi-account-outline font-16"></i></span>
                                      </div>
                                      <input type="text" class="form-control" required name="first_name" id="first_name" placeholder="Enter First Name">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="d-none" for="last_name">Last Name</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="mdi mdi-account-outline font-16"></i></span>
                                    </div>
                                    <input type="text" class="form-control" required name="last_name" id="last_name" placeholder="Enter Last Name">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="d-none" for="first_name">Company Name</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="mdi mdi-account-outline font-16"></i></span>
                                    </div>
                                    <input type="text" class="form-control" required name="company_name" id="company_name" placeholder="Enter Company Name">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="d-none" for="email">Email Address</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon2"><i class="mdi mdi-email-outline font-16"></i></span>
                                    </div>
                                    <input type="email" class="form-control" name="email" id="email" required parsley-type="email" placeholder="Email Address">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="d-none" for="password">Password</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon3"><i class="mdi mdi-lock-outline font-16"></i></span>
                                    </div>
                                    <input type="password" class="form-control" name="password" id="password" required data-parsley-minlength="6" placeholder="Enter password">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="d-none" for="password">Confirm Password</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon4"><i class="mdi mdi-key font-16"></i></span>
                                    </div>
                                    <input type="password" class="form-control" id="confirmpassword" required data-parsley-equalto="#password" placeholder="Confirm password">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="d-none" for="Mobile-number">Mobile Number</label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon5"><i class="mdi mdi-cellphone-iphone font-16"></i></span>
                                    </div>
                                    <input type="text" class="form-control" name="mo_number" id="mo_number" required data-parsley-pattern="[0-9]{10}" placeholder="Phone(10 numbers)">
                                </div>
                            </div>

                            <div class="form-group mb-0 row">
                                <div class="col-12 mt-2">
                                    <button class="btn btn-primary btn-block waves-effect waves-light" type="submit">Register <i class="fas fa-sign-in-alt ml-1"></i></button>
                                </div>
                            </div>
                        </form>

                    </div>

                    <div class="m-3 text-center bg-light p-3 text-primary d-none">
                        <h5 class="">Already have an account ? </h5>
                        <p class="font-13">Login 24hr Fast Funding Capital Now</p>
                        <a href="{{url('signin')}}" class="btn btn-primary btn-round waves-effect waves-light px-3">Log in</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-9 p-0 d-flex justify-content-center">
            <div class="accountbg d-flex align-items-center">
                <div class="account-title text-white text-center">
                    <img src="{{asset('assets/images/logo-light.png')}}" height="40" width="175" alt="">
                    <div class="border w-25 mx-auto border-primary"></div>
                    <h2 class="bold mt-3">Become Affiliate!</h2>
                    <h4 class="mt-3">And Earn $500 for each Refferal</h4>
                    <p class="font-14 mt-3">Already have an account ? <a href="{{url('/signin')}}" class="text-primary">Login</a></p>

                </div>
            </div>
        </div>
    </div>


    <!-- End Log In page -->
@endsection



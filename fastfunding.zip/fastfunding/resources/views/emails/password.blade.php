your changed password is: {{ $password }}

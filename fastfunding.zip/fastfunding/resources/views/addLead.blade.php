@extends('layouts.app')


<style>
    .modal-backdrop.show {
        z-index: 99;
    }
</style>

@section('content')
    <!-- Top Bar Start -->
    <div class="topbar">
        <!-- Navbar -->
        <nav class="navbar-custom">

            <!-- LOGO -->
            <div class="topbar-left mt-3">
                <a href="{{url('/')}}" class="logo">
                        <span>
                            <img src="{{asset('assets/images/logo-light.png')}}" alt="logo-large" style="height: 30px;" class="logo-lg">
                        </span>
                </a>
            </div>

            <ul class="list-unstyled topbar-nav float-right mb-0">

                <li class="dropdown">
                    <a class="nav-link dropdown-toggle waves-effect waves-light nav-user" data-toggle="dropdown" href="#" role="button"
                       aria-haspopup="false" aria-expanded="false">
                        <img src="{{asset('assets/images/users/user-1.jpg')}}" alt="profile-user" class="rounded-circle img-thumbnail mb-1"/>
                        <span class="online-icon" style="margin-left: -10px"><i class="mdi mdi-record text-success"></i></span>
                        <span class="ml-1 nav-user-name hidden-sm">
                            @if(Auth()->user()['permission'] > 4)
                                Admin
                            @else
                                {{Auth()->user()['first_name']}} {{Auth()->user()['last_name']}}
                            @endif

                            <i class="mdi mdi-chevron-down"></i>
                        </span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right">
                        <a class="dropdown-item" href="#"><i class="dripicons-user text-muted mr-2"></i> Profile</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" data-toggle="modal" data-animation="bounce" data-target=".bs-logout-modal-sm" href="">
                            <i class="dripicons-exit text-muted mr-2"></i> Logout</a>
                    </div>
                    <div class="modal fade bs-logout-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-sm">
                            <div class="modal-content">
                                <div class="modal-body" style="text-align: center">
                                    <h4 class="mt-2" style="text-align: center;color: white">Are you sure?</h4>
                                    <button type="button" class="btn btn-danger mt-2">
                                        <a href="{{url('/signout')}}" style="color: white">Yes, Logout</a>
                                    </button>
                                    <button type="button" class="btn btn-outline-light mt-2" data-dismiss="modal">
                                        Cancel
                                    </button>
                                </div>
                            </div><!-- /.modal-content -->
                        </div><!-- /.modal-dialog -->
                    </div><!-- /.modal -->
                </li>
                <li class="menu-item">
                    <!-- Mobile menu toggle-->
                    <a class="navbar-toggle nav-link" id="mobileToggle">
                        <div class="lines">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </a>
                    <!-- End mobile menu toggle-->
                </li>
            </ul>

        </nav>
        <!-- end navbar-->
    </div>
    <!-- Top Bar End -->
    <div class="page-wrapper-img" style="min-height: 111px">
        <div class="page-wrapper-img-inner d-none">
            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="page-title-box ml-0">
                        <h4 class="page-title mb-2">
                            <i class="mdi mdi-monitor mr-2"></i>
                            @if(Auth()->user()['permission'] > 4)
                                Leads
                            @else
                                Leads
                            @endif
                        </h4>
                        <div class="d-none">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item active">
                                    @if(Auth()->user()['permission'] > 4)
                                        Leads
                                    @endif
                                </li>
                            </ol>
                        </div>
                    </div><!--end page title box-->
                </div><!--end col-->
            </div><!--end row-->
            <!-- end page title end breadcrumb -->
        </div><!--end page-wrapper-img-inner-->
    </div><!--end page-wrapper-img-->

    <div class="page-wrapper">
        <div class="page-wrapper-inner">

            <!-- Navbar Custom Menu -->
            <div class="navbar-custom-menu">

                <div class="container-fluid">
                    <div id="navigation">
                        <!-- Navigation Menu-->
                        <ul class="navigation-menu list-unstyled">

                            <li class="has-submenu">
                                <a href="{{url('/')}}">
                                    <i class="mdi mdi-view-list"></i>
                                    Leads
                                </a>
                            </li>
                            <li class="has-submenu active">
                                <a href="{{url('/add')}}">
                                    <i class="mdi mdi-account"></i>
                                    Add New Lead
                                </a>
                            </li>
                            <li class="has-submenu">
                                <a href="{{url('/issue')}}">
                                    <i class="mdi mdi-contact-mail"></i>
                                    Issues
                                </a>
                            </li>

                        </ul>
                        <!-- End navigation menu -->
                    </div> <!-- end navigation -->
                </div> <!-- end container-fluid -->
            </div>
            <!-- end left-sidenav-->
        </div>
        <!--end page-wrapper-inner -->
        <!-- Page Content-->
        <div class="page-content">
            <div class="container-fluid">

                <div class="row">

                    <form class="form-horizontal my-4 w-50 m-auto" role="form" method="POST" action="{{ url('/add') }}">

                        <h4>Add New Lead!</h4>
                        @if(session('status_success'))
                            <div class="alert alert-outline-success alert-success-shadow mb-0 alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true"><i class="mdi mdi-close"></i></span>
                                </button>
                                <strong>SUCCESS:</strong> {{session('status_success')}}
                            </div>
                        @elseif(session('status_failed'))
                            <div class="alert alert-outline-danger alert-danger-shadow mb-0 alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true"><i class="mdi mdi-close"></i></span>
                                </button>
                                <strong>Failed:</strong> {{session('status_failed')}}
                            </div>

                        @endif

                        <div class="form-group mt-2">
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1"><i class="mdi mdi-account-outline font-16"></i></span>
                                </div>
                                <input type="text" class="form-control" required name="first_name" id="first_name" placeholder="Enter First Name">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1"><i class="mdi mdi-account-outline font-16"></i></span>
                                </div>
                                <input type="text" class="form-control" required name="last_name" id="last_name" placeholder="Enter Last Name">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon5"><i class="mdi mdi-cellphone-iphone font-16"></i></span>
                                </div>
                                <input type="text" class="form-control" name="mo_number" id="mo_number" required data-parsley-pattern="[0-9]{10}" placeholder="Phone(10 numbers)">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon2"><i class="mdi mdi-email-outline font-16"></i></span>
                                </div>
                                <input type="email" class="form-control" name="email" id="email" required parsley-type="email" placeholder="Email Address">
                            </div>
                        </div>

                        <div class="form-group">
                            <p class="text-muted font-14 mt-3 mb-2">
                                How would the client like to be contacted?
                            </p>
                            <div class="radio radio-info form-check-inline">
                                <input type="radio" id="emailRadio" value="1" name="radio" checked="">
                                <label for="emailRadio"> Email </label>
                            </div>
                            <div class="radio radio-info form-check-inline">
                                <input type="radio" id="textRadio" value="2" name="radio">
                                <label for="textRadio"> Text </label>
                            </div>
                            <div class="radio radio-info form-check-inline">
                                <input type="radio" id="callRadio" value="3" name="radio">
                                <label for="callRadio"> Call </label>
                            </div>
                            <div class="radio radio-info form-check-inline">
                                <input type="radio" id="anyRadio" value="4" name="radio">
                                <label for="anyRadio"> Any </label>
                            </div>
                            <div class="radio radio-info form-check-inline">
                                <input type="radio" id="readyRadio" value="5" name="radio">
                                <label for="readyRadio"> Client will contact when ready</label>
                            </div>
                        </div>

                        <div class="form-group">
                            <p class="text-muted font-14 mt-3 mb-2">
                                Please supply any information we should know about the client.
                            </p>
                            <div class="input-group mb-3">
                                <textarea class="form-control" name="memo" id="memo" required placeholder="Enter any extra information we should know about your client!"></textarea>
                            </div>
                        </div>

                        <div class="form-group mb-0 row">
                            <div class="col-12 mt-2">
                                <button class="btn btn-primary btn-block waves-effect waves-light" type="submit">Send Client Now <i class="fas fa-sign-in-alt ml-1"></i></button>
                            </div>
                        </div>

                    </form>
                </div><!--end row-->
            </div><!-- container -->

            <footer class="footer text-center text-sm-left">
                &copy; 2020 24hr Fast Funding Capital
            </footer>
        </div>
        <!-- end page content -->
    </div>
    <!-- end page-wrapper -->
@endsection

@section('script')
    <!-- Parsley js -->
    <script src="{{asset('assets/plugins/parsleyjs/parsley.min.js')}}"></script>
    <script src="{{asset('assets/pages/jquery.validation.init.js')}}"></script>
@endsection

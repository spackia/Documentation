<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title><?php echo e(Config::get('SITE_TITLE')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A premium admin dashboard template by mannatthemes" name="description" />
    <meta content="Mannatthemes" name="author" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo_icon.png')); ?>">

    

    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/metismenu.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css" />

    <?php echo $__env->yieldContent('css'); ?>

</head>

<body>


<?php echo $__env->yieldContent('content'); ?>


<!-- Scripts -->
<!-- jQuery  -->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/waves.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>




<script src="<?php echo e(asset('assets/plugins/moment/moment.js')); ?>"></script>




<script src="<?php echo e(asset('assets/pages/jquery.dashboard.init.js')); ?>"></script>

<script src="<?php echo e(asset('assets/plugins/custombox/custombox.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/custombox/custombox.legacy.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/pages/jquery.modal-animation.js')); ?>"></script>

<?php echo $__env->yieldContent('script'); ?>
<script src="<?php echo e(asset('assets/js/jquery.core.js')); ?>"></script>
<!-- App js -->
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>

</body>
</html>

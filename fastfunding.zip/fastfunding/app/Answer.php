<?php

namespace App;

/******************************************************
 * IM - Vocabulary Builder
 * Version : 1.0.2
 * Copyright© 2016 24hrfastfunding Ltd. All Rights Reversed.
 * This file may not be redistributed.
 * Author URL:http://24hrfastfunding.net
 ******************************************************/

use Illuminate\Database\Eloquent\Model;

class Answer extends Model
{
    protected $fillable = ['contents', 'word_id', 'question_id', 'type'];

    public function question()
    {
        return $this->belongsTo('App\Question');
    }

/*    public function createdBy()
    {
        return $this->belongsTo('App\User', 'created_by');
    }

    public function updatedBy()
    {
        return $this->belongsTo('App\User', 'updated_by');
    }*/
}

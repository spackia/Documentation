<?php
/**
 * Created by PhpStorm.
 * User: Olga
 * Date: 2020-01-29
 * Time: 10:05 AM
 */
namespace App;

class CustomRequestCaptcha
{
    public function custom()
    {
        return new \ReCaptcha\RequestMethod\Post();
    }
}
<?php

namespace App\Http\Controllers;

/******************************************************
 * IM - Vocabulary Builder
 * Version : 1.0.2
 * Copyright© 2016 Imprevo Ltd. All Rights Reversed.
 * This file may not be redistributed.
 * Author URL:http://imprevo.net
 ******************************************************/

use App\Cat;
use App\Lead;
use App\User;
use App\UserGroup;
use App\Course;
use App\Http\Requests;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Redirect;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(){
        $today=Carbon::now();
        $leads = Lead::all();
        if (Auth()->user()['permission'] < 4)
            $leads = Lead::where('affiliate_id', Auth()->user()['id'])->get();

        $revenue = 0;
        $deposit = 0;
        $deposit_data = Lead::where('affiliate_id', Auth()->user()['id'])->where('status', 7)->orderBy('created_at', 'desc')->get();
        $deposit_date = '';
        if ($deposit_data->count())$deposit_date = $deposit_data[0]->payout_date;

        $deposite_cash = Lead::where('affiliate_id', Auth()->user()['id'])->where('status', 7)->where('payout_date', $deposit_date)->get();
        for ($id = 0; $id < $deposite_cash->count(); $id += 1)
        {
            //  Payout sent to affiliate
            if ($deposite_cash[$id]->status == 7)
                $deposit += 500;
        }
        for ($id = 0; $id < $leads->count(); $id += 1)
        {
            //  Payout sent to affiliate
            if ($leads[$id]->status == 7 || $leads[$id]->status == 6 || $leads[$id]->status == 4)
                $revenue += 500;
        }
        return view('dashboard', [
            'leads' => $leads, 'today'=>$today, 'revenue'=>$revenue,'deposit'=>$deposit, 'deposit_date'=>$deposit_date
        ]);
    }

    public function users(Request $request)
    {
        $users = DB::table('users')->paginate(15);
        return view('users', [
            'users' => $users
        ]);
    }

    public function newUser()
    {
        return view('userEdit', [
            'userGroups' => UserGroup::all(),
            'courses' => Course::all(),
            'user' => array('id'=>null, 'name'=>'', 'email'=>'', 'permission'=>0, 'course'=>null)
        ]);
    }

    public function PermissionUser(Request $request) {
        $user = User::findOrNew($request->input('id'));
        $user->permission = $request->input('value');
        $user->save();
    }

    public function editUser(Request $request, $id)
    {
        return view('userEdit', [
            'userGroups' => UserGroup::all(),
            'courses' => Course::all(),
            'user' => User::findOrNew($id)
        ]);
    }

    public function postEdit(Request $request)
    {
        if($request->input('id') != '') {
            $user = User::findOrNew($request->input('id'));
            if(!$request->input('name')) {
                $pos = stripos($request->input('email'),"@");
                $userName =  substr($request->input('email'), 0, $pos);
            } else {
                $userName = $request->input('name');
            }

            $user->name = $userName;
            $user->permission = intval($request->input('permission'));
            $user->course = $request->input('course')?intval($request->input('course')):null;

            $user->save();
        } else {
            $exists = User::where('email', $request->input('email'))->get();
            if(sizeof($exists) > 0) {
                return Redirect::back()->withErrors("This email already used.");
            }
            $userName = "";

            if(!$request->input('name')) {
                $pos = stripos($request->input('email'),"@");
                $userName =  substr($request->input('email'), 0, $pos);
            } else {
                $userName = $request->input('name');
            }

            User::create([
                'email' => $request->input('email'),
                'password' => bcrypt($request->input('password')),
                'name' => $userName,
                'permission' => intval($request->input('permission')),
                'course' => $request->input('course')?intval($request->input('course')):null
            ]);
        }


        return redirect('/users');
    }

    public function destroy($id)
    {
    	$u = User::findOrNew($id);
        //$this->authorize('destroy', $category);
		//Cat::destroy([$category]);
        $u->delete();
        $ret = array("result"=>"ok");
        return json_encode($ret);
    }
}
